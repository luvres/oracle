DROP USER UPSNP CASCADE;
DROP TABLESPACE RGNPSNP INCLUDING CONTENTS AND DATAFILES;


CREATE TABLESPACE RGNPSNP
LOGGING DATAFILE 'RGNPSNP.dbf'
SIZE 100m AUTOEXTEND ON NEXT 100m EXTENT MANAGEMENT LOCAL;


CREATE USER UPSNP
IDENTIFIED BY UPSNP$00
DEFAULT TABLESPACE RGNPSNP
QUOTA UNLIMITED ON RGNPSNP;

GRANT
create session,
alter session,
create table,
create procedure,
create view,
create materialized view,
create trigger,
create sequence,
create any directory,
create type,
create synonym,
create any context
TO
UPSNP;

ALTER SESSION SET CURRENT_SCHEMA = UPSNP;

-- Gerado por Oracle SQL Developer Data Modeler 19.2.0.182.1216
--   em:        2019-12-03 14:11:06 GMT-03:00
--   site:      Oracle Database 11g
--   tipo:      Oracle Database 11g



CREATE TABLE tb_deducao (
    dedu_cd_id           NUMBER NOT NULL,
    dedu_dt_inicio       DATE,
    dedu_dt_fim          DATE,
    dedu_in_horastotal   NUMBER,
    offh_cd_id           NUMBER NOT NULL,
    dest_cd_id           CHAR(4 CHAR) NOT NULL
);

COMMENT ON TABLE tb_deducao IS
    'Dedu��es a realizar ap�s an�lise do Offhire';

COMMENT ON COLUMN tb_deducao.dedu_cd_id IS
    'C�digo identificador da dedu��o';

COMMENT ON COLUMN tb_deducao.dedu_dt_inicio IS
    'In�dio do per�odo de dedu��o';

COMMENT ON COLUMN tb_deducao.dedu_dt_fim IS
    'Fim do per�odo de dedu��o';

COMMENT ON COLUMN tb_deducao.dedu_in_horastotal IS
    'Total de horas a deduzir';

COMMENT ON COLUMN tb_deducao.offh_cd_id IS
    'C�digo de identifica��o do Offhire';

COMMENT ON COLUMN tb_deducao.dest_cd_id IS
    'C�digo identificador do estado da dedu��o';

ALTER TABLE tb_deducao ADD CONSTRAINT dedu_pk PRIMARY KEY ( dedu_cd_id );

CREATE TABLE tb_deducaostatus (
    dest_cd_id          CHAR(4 CHAR) NOT NULL,
    dest_tx_status      CHAR(32 BYTE),
    dest_tx_descricao   CHAR(64 BYTE)
);

COMMENT ON TABLE tb_deducaostatus IS
    'Estados poss�veis para a dedu��o de offhire';

COMMENT ON COLUMN tb_deducaostatus.dest_cd_id IS
    'C�digo identificador do estado da dedu��o';

COMMENT ON COLUMN tb_deducaostatus.dest_tx_status IS
    'Nome do estado da dedu��o';

COMMENT ON COLUMN tb_deducaostatus.dest_tx_descricao IS
    'Descri��o do estado da dedu��o';

ALTER TABLE tb_deducaostatus ADD CONSTRAINT dest_pk PRIMARY KEY ( dest_cd_id );

CREATE TABLE tb_documento (
    docu_cd_id          NUMBER NOT NULL,
    offh_cd_id          NUMBER NOT NULL,
    docu_nm_completo    CHAR(24 BYTE),
    docu_tx_descricao   CHAR(80 BYTE),
    docu_bl_arquivo     BLOB,
    edoc_cd_id          CHAR(60 BYTE),
    doti_cd_id          CHAR(4 BYTE) NOT NULL,
    dost_cd_id          CHAR(4 BYTE) NOT NULL
);

COMMENT ON COLUMN tb_documento.docu_cd_id IS
    'C�digo identificador do documento';

COMMENT ON COLUMN tb_documento.offh_cd_id IS
    'C�digo de identifica��o do Offhire';

COMMENT ON COLUMN tb_documento.docu_nm_completo IS
    'Nome do documento';

COMMENT ON COLUMN tb_documento.docu_tx_descricao IS
    'Descri��o do documento';

COMMENT ON COLUMN tb_documento.docu_bl_arquivo IS
    'Cont�m o arquivo propriamente dito';

COMMENT ON COLUMN tb_documento.edoc_cd_id IS
    'C�digo de identifica��o do documento no eDoc';

COMMENT ON COLUMN tb_documento.doti_cd_id IS
    'C�digo identificador do tipo de documento';

COMMENT ON COLUMN tb_documento.dost_cd_id IS
    'C�digo identificador do status do documento';

ALTER TABLE tb_documento ADD CONSTRAINT docu_pk PRIMARY KEY ( docu_cd_id );

CREATE TABLE tb_documentostatus (
    dost_cd_id          CHAR(4 BYTE) NOT NULL,
    dost_tx_status      CHAR(32 BYTE) NOT NULL,
    dost_tx_descricao   CHAR(64 BYTE)
);

COMMENT ON COLUMN tb_documentostatus.dost_cd_id IS
    'C�digo identificador do status do documento';

COMMENT ON COLUMN tb_documentostatus.dost_tx_status IS
    'Status do documento';

COMMENT ON COLUMN tb_documentostatus.dost_tx_descricao IS
    'Descri��o do status do documento';

ALTER TABLE tb_documentostatus ADD CONSTRAINT dost_pk PRIMARY KEY ( dost_cd_id );

CREATE TABLE tb_documentotipo (
    doti_cd_id          CHAR(4 BYTE) NOT NULL,
    doti_tx_tipo        CHAR(32 BYTE) NOT NULL,
    doti_tx_descricao   CHAR(64 BYTE)
);

COMMENT ON COLUMN tb_documentotipo.doti_cd_id IS
    'C�digo identificador do tipo de documento';

COMMENT ON COLUMN tb_documentotipo.doti_tx_tipo IS
    'Tipo de documento';

COMMENT ON COLUMN tb_documentotipo.doti_tx_descricao IS
    'Descri��o do tipo de documento';

ALTER TABLE tb_documentotipo ADD CONSTRAINT doti_pk PRIMARY KEY ( doti_cd_id );

CREATE TABLE tb_embarcacao (
    emba_cd_id         CHAR(4 BYTE) NOT NULL,
    emba_nm_completo   CHAR(31 BYTE) NOT NULL,
    emba_nm_apelido    CHAR(13 BYTE)
);

COMMENT ON TABLE tb_embarcacao IS
    'Embarca��o';

COMMENT ON COLUMN tb_embarcacao.emba_cd_id IS
    'C�digo do navio';

COMMENT ON COLUMN tb_embarcacao.emba_nm_completo IS
    'Nome do navio';

ALTER TABLE tb_embarcacao ADD CONSTRAINT emba_pk PRIMARY KEY ( emba_cd_id );

CREATE TABLE tb_offhire (
    offh_cd_id               NUMBER NOT NULL,
    viag_cd_id               VARCHAR2(12 BYTE) NOT NULL,
    espt_cd_id               NUMBER NOT NULL,
    poop_cd_id               VARCHAR2(4 BYTE) NOT NULL,
    evts_dt_registro         DATE,
    evts_dt_inicio           DATE,
    evts_dt_fim              DATE,
    offh_dt_inicioajustado   DATE,
    offh_dt_fimajustado      DATE,
    emba_cd_id               CHAR(4 BYTE) NOT NULL,
    ofst_cd_id               CHAR(4 BYTE) NOT NULL
);

COMMENT ON TABLE tb_offhire IS
    'Offhire';

COMMENT ON COLUMN tb_offhire.offh_cd_id IS
    'C�digo de identifica��o do Offhire';

COMMENT ON COLUMN tb_offhire.viag_cd_id IS
    'C�digo identificador da viagem';

COMMENT ON COLUMN tb_offhire.espt_cd_id IS
    'C�digo identificador da escala em porto';

COMMENT ON COLUMN tb_offhire.poop_cd_id IS
    'C�digo identificador do ponto operacional';

COMMENT ON COLUMN tb_offhire.evts_dt_registro IS
    'Data de registro do offhire no timesheet do SIGO';

COMMENT ON COLUMN tb_offhire.evts_dt_inicio IS
    'Data de in�cio do offhire registrada no timesheet do SIGO';

COMMENT ON COLUMN tb_offhire.evts_dt_fim IS
    'Data de t�rmino do offhire registrada no timesheet do SIGO';

COMMENT ON COLUMN tb_offhire.offh_dt_inicioajustado IS
    'Data de in�cio do offhire ajustada pelo operador do navio';

COMMENT ON COLUMN tb_offhire.offh_dt_fimajustado IS
    'Data de t�rmino do offhire ajustada pelo operador do navio';

COMMENT ON COLUMN tb_offhire.emba_cd_id IS
    'C�digo identificador da embarca��o';

COMMENT ON COLUMN tb_offhire.ofst_cd_id IS
    'C�digo identificador do status do Offhire';

ALTER TABLE tb_offhire ADD CONSTRAINT offh_pk PRIMARY KEY ( offh_cd_id );

CREATE TABLE tb_offhirestatus (
    ofst_cd_id          CHAR(4 BYTE) NOT NULL,
    ofst_tx_status      CHAR(32 BYTE) NOT NULL,
    ofst_tx_descricao   CHAR(64 BYTE)
);

COMMENT ON TABLE tb_offhirestatus IS
    'Status poss�veis para Offhire';

COMMENT ON COLUMN tb_offhirestatus.ofst_cd_id IS
    'C�digo identificador do status do Offhire';

COMMENT ON COLUMN tb_offhirestatus.ofst_tx_status IS
    'Status do offhire';

COMMENT ON COLUMN tb_offhirestatus.ofst_tx_descricao IS
    'Descri��o do status do offhire';

ALTER TABLE tb_offhirestatus ADD CONSTRAINT ofst_pk PRIMARY KEY ( ofst_cd_id );

CREATE TABLE tb_relato (
    rela_cd_id        NUMBER NOT NULL,
    rela_dt_emissao   DATE NOT NULL,
    rela_tx_relato    VARCHAR2(1024 BYTE) NOT NULL,
    usur_cd_chave     VARCHAR2(4 BYTE) NOT NULL,
    offh_cd_id        NUMBER NOT NULL,
    rlst_cd_id        CHAR(4 CHAR) NOT NULL
);

COMMENT ON COLUMN tb_relato.rela_cd_id IS
    'C�digo de identifica��o do relato';

COMMENT ON COLUMN tb_relato.rela_dt_emissao IS
    'Data de emiss�o do relato';

COMMENT ON COLUMN tb_relato.rela_tx_relato IS
    'Relato';

COMMENT ON COLUMN tb_relato.usur_cd_chave IS
    'Chave do usu�rio que gerou o relato';

COMMENT ON COLUMN tb_relato.offh_cd_id IS
    'C�digo de identifica��o do Offhire';

ALTER TABLE tb_relato ADD CONSTRAINT rela_pk PRIMARY KEY ( rela_cd_id );

CREATE TABLE tb_relatostatus (
    rlst_cd_id          CHAR(4 CHAR) NOT NULL,
    rlst_tx_status      CHAR(32 BYTE),
    rlst_tx_descricao   CHAR(64 BYTE)
);

COMMENT ON TABLE tb_relatostatus IS
    'Estados poss�veis para a dedu��o de offhire';

COMMENT ON COLUMN tb_relatostatus.rlst_cd_id IS
    'C�digo identificador do estado do relato';

COMMENT ON COLUMN tb_relatostatus.rlst_tx_status IS
    'Nome do estado do relato';

COMMENT ON COLUMN tb_relatostatus.rlst_tx_descricao IS
    'Descri��o do estado do relato';

ALTER TABLE tb_relatostatus ADD CONSTRAINT rlst_pk PRIMARY KEY ( rlst_cd_id );

CREATE TABLE tb_usuario (
    usur_cd_chave       VARCHAR2(4 BYTE) NOT NULL,
    usur_cd_matricula   VARCHAR2(12 BYTE),
    usur_nm_completo    VARCHAR2(50 BYTE),
    usur_nm_apelido     VARCHAR2(20 BYTE),
    usur_tx_perfil      VARCHAR2(4 BYTE) DEFAULT 'BAS'
);

ALTER TABLE tb_usuario
    ADD CONSTRAINT perfil CHECK ( usur_tx_perfil IN (
        'ADM',
        'BAS',
        'GCA',
        'ON'
    ) );

COMMENT ON TABLE tb_usuario IS
    'Usu�rios da aplica��o';

COMMENT ON COLUMN tb_usuario.usur_cd_chave IS
    'Chave do usu�rio';

COMMENT ON COLUMN tb_usuario.usur_cd_matricula IS
    'Matr�cula do usu�rio';

COMMENT ON COLUMN tb_usuario.usur_nm_completo IS
    'Nome do usu�rio';

COMMENT ON COLUMN tb_usuario.usur_nm_apelido IS
    'Apelido do usu�rio';

COMMENT ON COLUMN tb_usuario.usur_tx_perfil IS
    'Perfil do usu�rio';

ALTER TABLE tb_usuario ADD CONSTRAINT usur_pk PRIMARY KEY ( usur_cd_chave );

ALTER TABLE tb_deducao
    ADD CONSTRAINT deducao_deducaostatus_fk FOREIGN KEY ( dest_cd_id )
        REFERENCES tb_deducaostatus ( dest_cd_id );

ALTER TABLE tb_deducao
    ADD CONSTRAINT deducao_offhire_fk FOREIGN KEY ( offh_cd_id )
        REFERENCES tb_offhire ( offh_cd_id );

ALTER TABLE tb_documento
    ADD CONSTRAINT documento_documentostatus_fk FOREIGN KEY ( dost_cd_id )
        REFERENCES tb_documentostatus ( dost_cd_id );

ALTER TABLE tb_documento
    ADD CONSTRAINT documento_documentotipo_fk FOREIGN KEY ( doti_cd_id )
        REFERENCES tb_documentotipo ( doti_cd_id );

ALTER TABLE tb_documento
    ADD CONSTRAINT documento_offhire_fk FOREIGN KEY ( offh_cd_id )
        REFERENCES tb_offhire ( offh_cd_id );

ALTER TABLE tb_offhire
    ADD CONSTRAINT offhire_embarcacao_fk FOREIGN KEY ( emba_cd_id )
        REFERENCES tb_embarcacao ( emba_cd_id );

ALTER TABLE tb_offhire
    ADD CONSTRAINT offhire_offhirestatus_fk FOREIGN KEY ( ofst_cd_id )
        REFERENCES tb_offhirestatus ( ofst_cd_id );

ALTER TABLE tb_relato
    ADD CONSTRAINT relato_offhire_fk FOREIGN KEY ( offh_cd_id )
        REFERENCES tb_offhire ( offh_cd_id );

ALTER TABLE tb_relato
    ADD CONSTRAINT relato_relatostatus_fk FOREIGN KEY ( rlst_cd_id )
        REFERENCES tb_relatostatus ( rlst_cd_id );

ALTER TABLE tb_relato
    ADD CONSTRAINT relato_usuario_fk FOREIGN KEY ( usur_cd_chave )
        REFERENCES tb_usuario ( usur_cd_chave );



-- Relat�rio do Resumo do Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            11
-- CREATE INDEX                             0
-- ALTER TABLE                             22
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0

-- DEFINI��O DOS VALORES INICIAIS

-- STATUS DE DOCUMENTO
Insert into tb_documentostatus (dost_cd_id,dost_tx_status,dost_tx_descricao) values ('PEND','Pendente','Documento pendente de solicita��o');
Insert into tb_documentostatus (dost_cd_id,dost_tx_status,dost_tx_descricao) values ('SOLI','Solicitado','Documento solicitado');
Insert into tb_documentostatus (dost_cd_id,dost_tx_status,dost_tx_descricao) values ('ASSI','Assinado','Documento assinado');

COMMIT;


-- STATUS DE OFFHIRE
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('REGI','Registrado','Offhire registrado e sem respons�vel atribu�do');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('AGUA','Aguardando an�lise','Offhire com respons�vel atribu�do e sem an�lise iniciada');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('EMAN','Em an�lise','Offhire com an�lise em andamento');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('VALI','Validado','Offhire validado');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('PROV','Provisionado','Offhire provisionado');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('CANC','Cancelado','Offhire cancelado');
Insert into tb_offhirestatus (ofst_cd_id,ofst_tx_status,ofst_tx_descricao) values ('CONC','Conclu�do','Offhire com an�lise conclu�da e encaminhado para dedu��o');

COMMIT;

-- STATUS DE RELATO
Insert into tb_relatostatus (rlst_cd_id,rlst_tx_status,rlst_tx_descricao) values ('PEND','Pendente','Relato pendente');
Insert into tb_relatostatus (rlst_cd_id,rlst_tx_status,rlst_tx_descricao) values ('CONC','Conclu�do','Relato conclu�do');


-- TIPO DE DOCUMENTO
Insert into tb_documentotipo (doti_cd_id,doti_tx_tipo,doti_tx_descricao) values ('COOF','Comunicado de Offhire','Informa��es sobre o per�odo de Offhire');
Insert into tb_documentotipo (doti_cd_id,doti_tx_tipo,doti_tx_descricao) values ('COON','Comunicado de Onhire','Informa��es sobre o retorno do navio ao estado de Onhire');
Insert into tb_documentotipo (doti_cd_id,doti_tx_tipo,doti_tx_descricao) values ('RELA','Relato do operador','Relato gerado pelo operador do navio');

COMMIT;

-- STATUS DA DEDU��O
Insert into tb_deducaostatus (dest_cd_id,dest_tx_status,dest_tx_descricao) values ('EMCA','Em c�lculo','C�lculo da dedu��o em andamento');
Insert into tb_deducaostatus (dest_cd_id,dest_tx_status,dest_tx_descricao) values ('CALC','Calculada','C�lculo da dedu��o realizado');
Insert into tb_deducaostatus (dest_cd_id,dest_tx_status,dest_tx_descricao) values ('CANC','Cancelada','Dedu��o cancelada');
Insert into tb_deducaostatus (dest_cd_id,dest_tx_status,dest_tx_descricao) values ('REAL','Realizada','Encaminhada para tratamento posterior');


COMMIT;



REM INSERTING into TB_EMBARCACAO
SET DEFINE OFF;
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1Z4K','ABDIAS NASCIMENTO','ABDIAS 1Z4K');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('10QA','ALESSANDRO VOLTA','ALESSANDRO VO');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0F3V','ALEXANDROS M','ALEXANDROSM');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0RRF','ALIAKMON','ALIAKMON 0RRF');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1SJL','ALMI VOYAGER','ALMI 1SJL');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6276','AMAZON GLADIATOR','AMAZON 6276');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1RQ2','AMAZON VIRTUE','AMAZON 1RQ2');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('226O','AMBELOS','AMBELOS 226O');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1OA6','AMELIA PACIFIC','AMELIA 1OA6');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1V1P','ANDRE REBOU�AS','REBOUCAS 1V1P');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0SUV','ANEMOS I','ANEMOS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1DZ4','ANGRA DOS REIS','ANGRA DOS REI');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1V2A','ANITA GARIBALDI','ANITA GARIBAL');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('3641','APOSTOLOS','APOSTOLOS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6823','ARAL SEA','ARAL SEA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0UCR','ARAMON','ARAMON');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('19S9','ARCADIA I','ARCADIA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1LH8','ARCTURUS','ARCTURUS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1C1M','ARDMORE SEAMASTER','ARDMORE 1C1M');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('8541','ARIS','ARIS 8541');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('4321','ARTEMIS','ARTEMIS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1Y2C','ASIA DAWN','ASIA 1Y2C');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0ADJ','ASSOS','ASSOS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6305','ATAULFO ALVES','ATAULFO 6305');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1TLP','ATROTOS','ATROTOS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1PTQ','AVAX','AVAX 2');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1VZ2','BARBOSA LIMA SOBRINHO','BARBOSA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1JZ8','BRASIL 2014','BRASIL 2014');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0LYY','BW AUSTRIA','BWAUSTRIA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6301','CARTOLA','CARTOLA 6301');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('17MJ','CELSO FURTADO','FURTADO 17MJ');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1AFA','CEYLON','CEYLON');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('2100','CHALLENGE PASSAGE','CHALLENGEPASS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1ZQ9','CHALLENGE POINT','POINT 1ZQ9');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1W6O','CHILTERN','CHILTERN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('17OK','DAN CISNE','DAN CISNE');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0MWL','DAN EAGLE','DANEAGLE');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('19HD','DAN SABIA','DAN SABIA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1WPJ','DARCY RIBEIRO','DARCI');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0091','DILYA','DILYA 0091');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0089','DIVA','DIVA 0089');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1W5G','EAGLE','EAGLE');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1BHT','EAGLE PARAIBA','EAGLE PARAIBA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1CNU','EAGLE PARANA','EAGLE PARANA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('21X4','EAGLE VENICE','EAGLE V 21X4');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1YIH','ECO NICAL','ECO 1YIH');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('2003','ELKA ARISTOTLE','ELKAARISTOTLE');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1IJI','ELKA PARANA','ELKA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1089','ELKA VASSILIKI','ELKA VASSILIK');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0368','EMMANUEL TOMASOS','EMMANUELTOMAS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1YLJ','EPIC BALUAN','EPIC 1YLJ');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6826','EVROS','EVROS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0W5S','FLUMAR BRASIL','FLUMAR');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('14OZ','FORTALEZA KNUTSEN','FORTALEZA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('08CK','FORTE DE COPACABANA','FORTE 08CK');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('20Y4','GILBERTO FREYRE','GILBERTO 20Y4');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0L7V','GOLAR WINTER','GOLAR WINTER');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0113','GRAJAU','GRAJAU 0113');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0114','GURUPA','GURUPA 0114');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0115','GURUPI','GURUPI 0115');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1UA4','HENRIQUE DIAS','HENRIQUE 1UA4');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1VEX','HIGH CURRENT','HIGH 1VEX');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1VQE','IGLC DICLE','IGLC 1VQE');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1HZQ','JOSE ALENCAR','JOSE ALENCAR');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1W1Q','JOSE DO PATROCINIO','JOSE 1W1Q');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0SY7','KRONBORG','KRONBORG 0SY7');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0138','LINDOIA BR','LINDOIA BR');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0139','LIVRAMENTO','LIVRAMENTO');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1X5F','LUCIO COSTA','LUCIO COSTA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1DZ5','MADRE DE DEUS','MADRE DE DEUS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('12BF','MAERSK KALEA','MAERSK 12BF');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0094','MAISA','MAISA 0094');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('14Y0','MARLIN','MARLIN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0099','MARTA','MARTA 0099');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1V55','MARVEL','MARVEL');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1YG8','MILTON SANTOS','MILTON 1YG8');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('21ZD','MINERVA CORALIA','MIN COR  21ZD');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1UOO','MR CANOPUS','MR CANOPUS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1U8O','MR KENTAURUS','KENTAURUS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1T1I','MR PAT BROWN','MR PAT BROWN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1SS6','MR SIRIUS','MR SIRIUS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0103','NARA','NARA 0103');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('9752','NAVION GOTHENBURG','NAVIONGOTHENB');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1421','NAVION STAVANGER','NAVION STAVAN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0104','NEUSA','NEUSA 0104');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0096','NILZA','NILZA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('2365','NORD FARER','NORD FARER');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6482','NORDIC SPIRIT','NORDICSPIR');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0102','NORMA','NORMA 0102');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('17P6','OCEAN DIGNITY','OCEANDIGNITY');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1W72','OCEAN QUEST','OCEANQUEST');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0N3X','OCEAN SPIRIT','OCEAN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('215X','ORIENT INNOVATION','ORIENT I 215X');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1UZH','OSCAR NIEMEYER','NIEMEYER');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0122','PIRAI','PIRAI');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1W2V','PORTMAN','PORTMAN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('17I7','RECIFE KNUTSEN','RECIFE KNUSTS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1VAF','RIMAR','RIMAR');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('C101','RIO GRANDE','RIOGRA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1IMB','RIO 2016','RIO 2016');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1HZM','ROMULO ALMEIDA','ROMULO 1HZM');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6891','ROSA TOMASOS','ROSATOMASO');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0Z1E','SAHBA','SAHBA 0Z1E');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1YJC','SANTOS','SANTOS 1YJC');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1FKB','SAO SEBASTIAO','SAO SEBASTIAO');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('21XO','SEAWAYS KILIMANJARO','SEAWAYS 21XO');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1BW2','SERGIO BUARQUE DE HOLANDA','SERGIO 1BW2');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('196N','SESTREA','SESTREA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1WTB','SILVER MILLIE','SILVER M 1WTB');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1H62','STENA PROGRESS','STENA');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('6429','STENA SPIRIT','STENA 6429');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('21WF','STENAWECO ELEGANCE','STENAW 21WF');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1VQ4','STI MANHATTAN','MANHATTAN');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('7469','STRYMON','STRYMON');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('20MG','SUPERBA','SUPERBA 20MG');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0PF2','TI HELLAS','TIHELLAS');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1700','TORM GUNHILD','TORM GUNHILD');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1J7E','TORM KRISTINA','TORM');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0ZM9','TORM ROSETTA','TORM 0ZM9');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('0AEY','TORM SAN JACINTO','TORM SAN JACI');
Insert into TB_EMBARCACAO (EMBA_CD_ID,EMBA_NM_COMPLETO,EMBA_NM_APELIDO) values ('1HZS','ZUMBI DOS PALMARES','ZUMBI 1HZS');

COMMIT;

CREATE TABLE UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET 
(
  GTEV_CD_ID VARCHAR2(1 BYTE) NOT NULL 
, GTEV_NM_COMPLETO VARCHAR2(50 BYTE) 
, GTEV_IN_ATRASO NUMBER(1, 0) 
, CONSTRAINT GTEV_PK PRIMARY KEY 
  (
    GTEV_CD_ID 
  )
  ENABLE 
);

--CREATE UNIQUE INDEX UPSNP.GTEV_PK ON UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID ASC);


--CREATE UNIQUE INDEX UPSNP.GTEV_UN_1 ON UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_NM_COMPLETO ASC);

COMMENT ON COLUMN UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET.GTEV_CD_ID IS 'C�DIGO DO GRUPO DE TIPO DE EVENTO DE TIME SHEET';
COMMENT ON COLUMN UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET.GTEV_NM_COMPLETO IS 'NOME DO GRUPO DE TIPO DE EVENTO DE TIME SHEET';
COMMENT ON COLUMN UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET.GTEV_IN_ATRASO IS 'INDICADOR DE ATRASO';

ALTER TABLE UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT GTEV_UN_1 UNIQUE 
(
  GTEV_NM_COMPLETO 
)
ENABLE;



ALTER TABLE UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT GTEV_GTEV_NM_COMPLETO_NN CHECK 
(GTEV_NM_COMPLETO IS NOT NULL)
ENABLE;

COMMENT ON TABLE UPSNP.GRUPO_TIPO_EVENTO_TIME_SHEET IS 'GRUPO DE TIPO DE EVENTO DE TIME SHEET';

Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('0','OUTROS',null);
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('1','OPERA��O',null);
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('2','OFF-HIRE','-1');
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('3','ATRASOS E INTERRUP��ES PELO CLIENTE','-1');
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('4','ATRASOS E INTERRUP��ES - CAUSAS VARI�VEIS','-1');
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('5','MANOBRAS COM REBOCADOR',null);
Insert into GRUPO_TIPO_EVENTO_TIME_SHEET (GTEV_CD_ID,GTEV_NM_COMPLETO,GTEV_IN_ATRASO) values ('6','ICDN',null);

COMMIT;

CREATE TABLE TIPO_EVENTO_TIME_SHEET 
(
  TETS_CD_ID VARCHAR2(3 BYTE) NOT NULL 
, TETS_NM_COMPLETO VARCHAR2(75 BYTE) 
, GTEV_CD_ID VARCHAR2(1 BYTE) 
, TETS_IN_CRITICAR NUMBER(1, 0) DEFAULT 0 
, TETS_NM_COMPLETO_INGLES VARCHAR2(75 BYTE) 
, CONSTRAINT TETS_PK PRIMARY KEY 
  (
    TETS_CD_ID 
  )
  ENABLE 
);

COMMENT ON COLUMN TIPO_EVENTO_TIME_SHEET.TETS_CD_ID IS 'C�DIGO DO TIPO DE EVENTO TIME SHEET';
COMMENT ON COLUMN TIPO_EVENTO_TIME_SHEET.TETS_NM_COMPLETO IS 'NOME DO TIPO DE EVENTO TIME SHEET';
COMMENT ON COLUMN TIPO_EVENTO_TIME_SHEET.GTEV_CD_ID IS 'C�DIGO GRUPO DO TIPO DE EVENTO TIME SHEET';
COMMENT ON COLUMN TIPO_EVENTO_TIME_SHEET.TETS_IN_CRITICAR IS 'INDICA SE O TIPO DO EVENTO SERA CRITICADO CONTRA QTP E QTO DA ESCALA PORTO CORRESPONDENTE';
COMMENT ON COLUMN TIPO_EVENTO_TIME_SHEET.TETS_NM_COMPLETO_INGLES IS 'NOME DO TIPO DE EVENTO TIME SHEET EM INGL�S';

ALTER TABLE TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT TETS_GTEV_FK FOREIGN KEY
(
  GTEV_CD_ID 
)
REFERENCES GRUPO_TIPO_EVENTO_TIME_SHEET
(
  GTEV_CD_ID 
)
ENABLE;

ALTER TABLE TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT TETS_UN_1 UNIQUE 
(
  TETS_NM_COMPLETO 
)
ENABLE;



ALTER TABLE TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT TETS_GTEV_CD_ID_NN CHECK 
(GTEV_CD_ID IS NOT NULL)
ENABLE;

ALTER TABLE TIPO_EVENTO_TIME_SHEET
ADD CONSTRAINT TETS_TETS_NM_COMPLETO_NN CHECK 
(TETS_NM_COMPLETO IS NOT NULL)
ENABLE;

COMMENT ON TABLE TIPO_EVENTO_TIME_SHEET IS '� a classifica��o (nome) dos tipos de time sheet (eventos de atividades das embarca��es) e suas dura��es correspondentes Ex. Desatraca��o / Desamarra��o, Opera��o (Carga/Descarga), Navio manobrando sem rebocador Atraca��o/Desatraca��o, etc...';


Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('135','Z N�o usar - (Surveyor a bordo na chegada)','1','-1','Z Do not use this event - (Cargo Surveyor on board on arrival)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('136','Z N�o usar - (Surveyor a bordo na sa�da)','1','-1','Z Do not use this event - (Cargo Surveyor on board on departure)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('510','Nome dos Rebocadores utilizados na Manobra','5','-1','Tugboats names used on manouvering');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('131','Z N�o usar - (Medi��o inicial)','1','-1','Z Do not use this event - (Initial tanks'' gauging)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('132','Z N�o usar - (Medi��o final)','1','-1','Z Do not use this event - (Final tanks'' gauging)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('101','   Pronto a operar','1','-1','   Notice of Readiness');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('102','Fundeio','1','-1','Anchored');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('103','Libera��o p/ autorid. portu�rias','1','0','Clearance by Port Authorities');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('104','  Atraca��o / Amarra��o','1','-1','  Mooring');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('105',' Desatraca��o / Desamarra��o','1','-1',' Unmooring');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('106','Abastecimento de Comb. (FO/DO)','1','-1','Bunkering (IFO/MDO)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('107','Opera��o (Carga/Descarga)','1','-1','Loading / Discharging Operation');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('108','Crude Oil Washing','1','-1','Crude Oil Washing');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('109','Libera��o inicial','1','-1','Initial inspection');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('110','Libera��o final','1','-1','Final inspection');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('111','  Conex�o do Mangote / Bra�o','1','-1',' Hose(s) / Arm(s) connection');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('112','  Desconex�o do Mangote / Bra�o','1','-1',' Hose(s) / Arm(s) disconnection');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('113','Lastro/Deslastro','1','-1','Ballast / Deballast');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('114','Escada de Acesso','1','-1','Gangway');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('115','Outro evento operacional (especificar)','1','-1','Other operational event (to be specified in remark)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('201','Z N�o usar - (Habilita��o)','2','-1','Z Do not use this event - (Awaiting vessel''s certificates)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('202','Z N�o usar - (Reparo/Material)','2','0','Z Do not use this event - (Repairs / Material)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('203','Docagem','2','0','Drydocking');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('204','Z N�o usar - (Inc�ndio/Polui��o/Encalhe oriundo de bordo)','2','0','Z Do not use this event - (Fire/Spillage/Grounding)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('205','Z N�o usar - (Interrup��es em carga/descarga)','2','-1','Z Do not use this event - (Loading / Discharge Interrupted by vessel)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('206','Z N�o usar - (Parado em Abast. (excu�do FO/DO))','2','-1','Z Do not use this event - (Loading / discharging stoppage due to bunke');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('207','Quebra de Equipamentos','6','0','Vessel''s breakdown');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('301','Z N�o usar - (Aguardando Programa��o)','3','-1','Z Do not use this event - (Awaiting  Charterer''s Orders)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('302','Z N�o usar - (Aguardando analise de carga)','3','-1','Z Do not use this event - (Awaiting cargo analysis'' by the Charterers)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('303','Z N�o usar - (Aguardando espa�o tanque em terra)','3','-1','Z Do not use this event - (Awaiting shore tanks'' readiness)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('304','Z N�o usar - (Aguardando ber�o livre)','3','-1','Z Do not use this event - (Awaiting berth)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('305','Z N�o usar - (Aguardando libera��o de terra)','3','-1','Z Do not use this event - (Awaiting terminal''s readiness)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('306','Z N�o usar - (Quebra de equipamento no terminal)','3','-1','Z Do not use this event - (Terminal''s breakdown)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('307','Z N�o usar - (Interup��es durante carga e descarga)','3','-1','Z Do not use this event - (Loading / Discharging Interruption by the t');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('401','Z N�o usar - (Aguardando devido mau tempo)','4','-1','Z Do not use this event - (Awaiting weather improvement)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('402','Z N�o usar - (Aguardando Mar�)','4','-1','Z Do not use this event - (Awaiting tide)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('403','Z N�o usar - (Aguardando Amanhecer)','4','-1','Z Do not use this event - (Awaiting daylight)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('404','Z N�o usar - (Agente (pr�tico, rebocador))','4','-1','Z Do not use this event - (Agents (Pilot, Tugs))');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('405','Z N�o usar - (Aguardando Abastecimento FO/DO)','4','-1','Z Do not use this event - (Awaiting bunkering (IFO/MDO))');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('406','Z N�o usar - (Demora causada por autoridade portu�ria)','4','-1','Z Do not use this event - (Awaiting Port Authorities)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('407','Z N�o usar - (Falta de acesso ao terminal)','4','-1','Z Do not use this event - (Awaiting due to no access to terminal�s ins');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('408','Espera / Interrup��o da opera��o por outros motivos (especificar)','4','-1','Delay / Interruption on operation for other reasons (specify)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('501','Manobras com Reboc. (Atraca��o)','5','-1','Manouver with Tugboat ( Mooring )');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('502','Manobras com Reboc. (Desatraca��o)','5','-1','Manouver with Tugboat ( Unmooring )');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('503','Manobras com Reboc. (Giro)  Dist < 300m','5','-1','Manouver with Tugboat ( Turn ) Dist < 300m');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('504','Manobras com Reboc. (Acomp. com cabo)','5','-1','Manouver with Tugboat ( Scort with line )');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('505','Manobras com Reboc. (Acomp. sem cabo)','5','-1','Manouver with Tugboat ( Scort without line )');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('116','Z N�o usar - (Chegada no porto)','1','-1','Z Do not use this event - (Arrival in port)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('117','Z N�o usar - (Hora Oficial de Chegada)','1','-1','Z Do not use this event - (Official Time of Arrival (End of sea passag');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('118','Z N�o usar - (Hora Oficial de Sa�da)','1','-1','Z Do not use this event - (Official Time of Departure (Commencement of');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('308','Espera / Interrup��o da opera��o por demanda do terminal (especificar)','3','-1','Delay / Interruption on operation for terminal''s reasons (specify)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('208','Off-hire (especificar)','2','0','Off-hire (to be specified in remark)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('119','Z N�o usar - (Navio manobrando sem rebocador Atraca��o/Desatraca��o)','1','-1','Z Do not use this event - (Manouvering without tug)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('120','Z N�o usar - (Aguardando alinhamento do terminal)','1','-1','Z Do not use this event - (Awaiting terminal''s line-up)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('121','Z N�o usar - (NOR (aceite))','1','-1','Z Do not use this event - (NOR (Accepted))');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('122','Z N�o usar - (NOR (emiss�o))','1','-1','Z Do not use this event - (NOR (Tendered))');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('123','Z N�o usar - (Calado de Chegada)','1','-1','Z Do not use this event - (Arrival draft)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('124','Z N�o usar - (Calado de Chegada no Proximo Porto)','1','-1','Z Do not use this event - (Next port arrival draft)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('125','Pr�tico a bordo','1','0','Pilot on board');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('126','Z N�o usar - (Pratico a bordo na sa�da)','1','0','Z Do not use this event - (Pilot on board on departure)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('127','Z N�o usar - (Primeiro cabo para terra)','1','-1','Z Do not use this event - (First line ashore)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('409','Z N�o usar - (Aguardando manobras a bordo)','4','-1','Z Do not use this event - (Awaiting vessel''s readiness)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('410','Z N�o usar - (Aguardando manobra do terminal)','4','-1','Z Do not use this event - (Awaiting terminal''s maneuvers)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('134','Shifting','1','-1','Shifting');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('506','Coloca��o de defensas','1','-1','Fendering');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('411','Z N�o usar - (Aguardando pessoal para conex�o/desconex�o)','4','-1','Z Do not use this event - (Awaiting connection / disconnection staff)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('128','Z N�o usar - (Deslocamento inicial de linha)','1','-1','Z Do not use this event - (Initial line displacement)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('129','Z N�o usar - (Deslocamento final de linha)','1','-1','Z Do not use this event - (Final line displacement)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('130','Z N�o usar - (Passagem de PIG)','1','-1','Z Do not use this event - (Pigging)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('412','Z N�o usar - (Espera de OM 1/93)','4','-1','Z Do not use this event - ()');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('209','Polui��o (abaixo de 50 litros) ou acidente (sem feridos)','6','0','Pollution (less than 50 l) or accident (no wounded people)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('210','Polui��o (acima de 50 litros) ou acidente (com feridos)','6','0','Pollution (more than 50 l) or accident (wounded people)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('211','Polui��o (acima de 100 litros) ou acidente (com mortes)','6','0','Pollution (more than 100 l) or accident (dead people)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('212','Contamina��o ou perda de carga','6','0','Cargo contamination or loss');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('213','N�o cumprimento de programac�es','6','0','Unfilled charterer''s instructions');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('214','Z N�o usar - (Encalhe oriundo de bordo)','2','-1','Z Do not use this event - ()');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('507','Retidada de defensas','1','-1','Unfendering');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('508','Espera / Interrup��o da opera��o por demanda do navio (especificar)','4','-1','Delay / Interruption on operation for vessel''s reasons (specify)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('509','Z N�o usar - (DOCUMENTA��ES)','0','-1','Z Do not use this event - (DOCUMENTATIONS)');
Insert into TIPO_EVENTO_TIME_SHEET (TETS_CD_ID,TETS_NM_COMPLETO,GTEV_CD_ID,TETS_IN_CRITICAR,TETS_NM_COMPLETO_INGLES) values ('133','Prepara��o dos tanques do navio','1','-1','Awaiting vessel''s cargo tanks readiness');

COMMIT;

--------------------------------------------------------
--  DDL for Sequence TB_OFFHIRE_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "UPSNP"."TB_OFFHIRE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;


--------------------------------------------------------
--  DDL for Trigger TB_OFFHIRE_TRG
--------------------------------------------------------

CREATE OR REPLACE TRIGGER "UPSNP"."TB_OFFHIRE_TRG" 
BEFORE INSERT ON TB_OFFHIRE 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.OFFH_CD_ID IS NULL THEN
      SELECT TB_OFFHIRE_SEQ.NEXTVAL INTO :NEW.OFFH_CD_ID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "UPSNP"."TB_OFFHIRE_TRG" ENABLE;

--------------------------------------------------------
--  DDL for Sequence TB_DOCUMENTO_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "UPSNP"."TB_DOCUMENTO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;


--------------------------------------------------------
--  DDL for Trigger TB_DOCUMENTO_TRG
--------------------------------------------------------

CREATE OR REPLACE TRIGGER "UPSNP"."TB_DOCUMENTO_TRG" 
BEFORE INSERT ON TB_DOCUMENTO 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.DOCU_CD_ID IS NULL THEN
      SELECT TB_DOCUMENTO_SEQ.NEXTVAL INTO :NEW.DOCU_CD_ID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "UPSNP"."TB_DOCUMENTO_TRG" ENABLE;


--------------------------------------------------------
--  DDL for Sequence TB_RELATO_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "UPSNP"."TB_RELATO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;


--------------------------------------------------------
--  DDL for Trigger TB_RELATO_TRG
--------------------------------------------------------

CREATE OR REPLACE TRIGGER "UPSNP"."TB_RELATO_TRG" 
BEFORE INSERT ON TB_RELATO 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.RELA_CD_ID IS NULL THEN
      SELECT TB_RELATO_SEQ.NEXTVAL INTO :NEW.RELA_CD_ID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "UPSNP"."TB_RELATO_TRG" ENABLE;


--------------------------------------------------------
--  DDL para cria��o dos objetos necess�rios para a
--  t�cnica de tratamento de "bind variables" em 
--  cl�usulas IN. Exemplo adaptado da p�gina
--  https://asktom.oracle.com/Misc/varying-in-lists.html
--------------------------------------------------------
CREATE OR REPLACE CONTEXT my_ctx USING my_ctx_procedure;
/
CREATE OR REPLACE PROCEDURE my_ctx_procedure (
    p_str IN VARCHAR2
) AS
BEGIN
    dbms_session.set_context('my_ctx', 'txt', p_str);
END;
/

CREATE OR REPLACE VIEW in_list AS
    SELECT
        TRIM(substr(txt, instr(txt, ',', 1, level) + 1, instr(txt, ',', 1, level + 1) - instr(txt, ',', 1, level) - 1)) AS token
    FROM
        (
            SELECT
                ','
                || sys_context('my_ctx', 'txt')
                || ',' txt
            FROM
                dual
        )
    CONNECT BY
        level <= length(sys_context('my_ctx', 'txt')) - length(replace(sys_context('my_ctx', 'txt'), ',', '')) + 1;

