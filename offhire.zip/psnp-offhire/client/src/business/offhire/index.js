import get from './get'
import insert from './insert'

export default {
  get,
  insert
}