import { fetchDataPending, fetchDataSuccess, showSnack } from '../../actions'
import Axios from 'axios'
import 'regenerator-runtime/runtime'

/** @typedef OffhireGetOptions
 * @property {'S' | 'N'} myFleet Se igual a "S", filtra os offhires pelas embarcações da frota do usuário
 */

/**
 * Recupera os *OFFHIRE* registrados na aplicação
 * @param {OffhireGetOptions} options Opções para modificação da consulta
 * @param {import('redux').Dispatch} dispatch Função usada como *dispatch* para disparar ações do Redux
 */
export default async function (options, dispatch) {
  const baseURL = 'http://10.22.218.136:3000/api/offhires'
  const params = options
    ? [options.myFleet && options.myFleet === 'S' ? '/myfleet' : '']
    : []
  const url = `${baseURL}${params.join()}`

  dispatch(fetchDataPending())

  return await Axios.get(url)
    .then(result => {
      dispatch(fetchDataSuccess(result.data.rows))
      dispatch(showSnack('Offhires carregados com sucesso!'))
    })
    .catch(err => console.log(err))
}
