import Axios from 'axios'
import 'regenerator-runtime/runtime'

/**
 * Cria um novo *Offhire*
 * @param {object} data Dados do novo *offhire*
 * @param {function(object)} resolve Callback para o sucesso da operação. Recebe os dados retornados.
 * @param {function(object)} reject Callback para erro na operação. Recebe o erro ocorrido.
 */
export default async function (data, resolve, reject) {
  const url = 'http://10.22.218.136:3000/api/offhires'

  return await Axios.post(url, data, {
    headers: { 'Content-Type': 'application/json' }
  })
    .then(result => {
      resolve(result.data)
    })
    .catch(err => reject(err))
}
