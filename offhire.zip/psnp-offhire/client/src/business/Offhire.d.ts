import { Action, ActionName } from "./Action";

/** Estados possíveis para um offhire */
export type OffhireStatus = 'REGI' | 'EMAN' | 'AGUA' | 'VALI' | 'PROV' | 'CANC' | 'CONC';


/** Objeto que representa um Offhire */
export interface Offhire {
  /** Viagem */
  voyage: string;

  /** Embarcação */
  vessel: string;

  /** Ponto operacional */
  portCall: string;

  /** Data de chegada ao ponto operacional */
  qtp: Date;

  /** Data e hora do início do offhire */
  start: Date;

  /** Data e hora do início do offhire */
  end: Date;

  /** Status do offhire */
  status: OffhireStatus;

  /** Duração do offhire, em horas */
  duration: number

}

/**
 * Fornece uma lista de ações que podem ser executadas de acordo com o estado do offhire
 * @param offhire Offhire
 */
export function offhireActionNames(offhire: Offhire): ActionName[];