import { fetchDataPending, fetchDataSuccess, showSnack } from '../../actions'
import Axios from 'axios'
import 'regenerator-runtime/runtime'

/**@typedef TimesheetGetOptions
 * @property {'S' | 'N'} myFleet Se igual a "S", filtra os eventos pelas embarcações da frota do usuário
 */


 /**
  * Recupera os eventos do tipo *OFFHIRE* registrados no timesheet do SIGO 
  * @param {TimesheetGetOptions} options Opções para modificação da consulta
  * @param {import('redux').Dispatch} dispatch Função usada como *dispatch* para disparar ações do Redux 
  * @param {function(any)} resolve Callback que retorna os dados 
  */
export default async function(options, dispatch) {
  const baseURL = 'http://10.22.218.136:3000/api/sigo/timesheet'
    const params = options ? [
      options.myFleet && options.myFleet === 'S' ? '/myfleet' : ''
    ] : []
    const url = `${baseURL}${params.join()}`

    dispatch(fetchDataPending())

    return await Axios.get(url)
      .then(result => {
        dispatch(fetchDataSuccess(result.data.rows))
        dispatch(showSnack('Eventos carregados com sucesso!'))
      })
      .catch(err => console.log(err))
}