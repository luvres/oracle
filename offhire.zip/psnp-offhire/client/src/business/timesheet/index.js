import get from './get'

export default {
  get
}