import { red, green } from '@material-ui/core/colors'


const _defaultPromise = new Promise((resolve, reject) => {
  resolve('default promise resolved!')
})


/** @type {import('./Action').Action[]} */
const _actions = [
  {
    name: 'attachFile',
    label: 'Anexar arquivo',
    description: 'Anexa um arquivo à análise do offhire',
    icon: 'attach_file',
    trigger: _defaultPromise
  },
  {
    name: 'createReport',
    label: 'Criar relato',
    description: 'Cria um relato para o offhire',
    icon: 'create',
    trigger: _defaultPromise
  },
  {
    name: 'editReport',
    label: 'Editar relato',
    description: 'Edita um relato existente para o offhire',
    icon: 'create',
    trigger: _defaultPromise
  },
  {
    name: 'communicateOffhire',
    label: 'Comunicar Offhire',
    description: 'Comunica à embarcação a ocorrência de Offhire',
    icon: 'email',
    color: red[700],
    trigger: _defaultPromise
  },
  {
    name: 'communicateOnhire',
    label: 'Comunicar Onhire',
    description: 'Solicita à embarcação o comunicado de Onhire',
    icon: 'email',
    color: green[700],
    trigger: _defaultPromise
  },
]

export function getAction(actionName){
  return _actions.find(action => action.name === actionName)
}

/**
 * 
 * @param {import('./Action').ActionName[]} actionNames 
 */
export function getActions(actionNames){
  const actions = []
  if(actionNames)actionNames.forEach(actionName => actions.push(getAction(actionName)))
  return actions
}