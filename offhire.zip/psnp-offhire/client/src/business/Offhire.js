'use strict'


Object.defineProperty(exports, '__esModule', {
  value: true
})

exports.offhireActionNames = _offhireActionNames

/**
 * Fornece uma lista de ações que podem ser executadas de acordo com o estado do offhire
 * @param {import("./Offhire").Offhire} offhire Offhire
 * @returns {import("./Action").ActionName[]}
 */
function _offhireActionNames (offhire) {

  switch (offhire.STATUS_OFFHIRE_ID) {
    case 'REGI':
      return [
        'attachFile',
        'createReport',
        'communicateOffhire',
        'communicateOnhire'
      ]
    case 'AGUA':
      return ['attachFile', 'createReport']
    case 'EMAN':
      return ['attachFile', 'communicateOnhire']
    case 'VALI':
    case 'PROV':
    case 'CANC':
      return ['editReport']
    case 'CONC':
      return []
    default:
      void 0
      break
  }
}
