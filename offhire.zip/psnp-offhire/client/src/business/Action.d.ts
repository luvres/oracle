/** Ações possíveis para um offhire */
export type ActionName = 'communicateOffhire' | 'communicateOnhire' | 'attachFile' | 'createReport' | 'editReport';

export interface Action {
  /** Identificador da ação */
  name: ActionName;

  /** Rótulo da ação */
  label: string;

  /** Texto descritivo da ação */
  description?: string;

  /** Nome do ícone que representa a ação. Deve ser uma das opções do Material Design System (https://material.io/resources/icons/?style=baseline) */
  icon: string;

  /** Cor da ação, no formato hexadecimal */
  color?: string

  /** Executa a ação */
  trigger(): Promise;
}

/**
 * Retorna uma ação de acordo com o nome fornecido
 * @param actionName Nome da ação
 */
export function getAction(actionName: ActionName):Action

/**
 * Retorna um conjunto de ações de acordo com os nomes de ação fornecidos
 * @param actionNames Array com os nomes das ações
 */
export function getActions(actionNames: ActionName[]):Action[]