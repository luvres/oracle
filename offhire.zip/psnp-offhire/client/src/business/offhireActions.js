import React from 'react'
import { getAction } from './Action'
import uuid from 'uuid'
import {
  businessPending,
  businessSuccess,
  fetchDataPending,
  fetchDataSuccess,
  openModal
} from '../actions'
import offhireAPI from '../business/offhire/'
import store from '../store'
import { useSelector } from 'react-redux'
import { OffhireStoryForm } from '../components/forms/OffhireStoryForm'
import { OffhireCommunicateForm } from '../components/forms/OffhireCommunicateForm'

let _dispatch = null

/**
 * Retorna um objeto derivado do original, apenas com as propriedades
 * selecionadas.
 * @param {object} obj Objeto original
 * @param {string[]} arrProps Array com os nomes das propriedades
 */
function _selectProps (obj, arrProps) {
  const newObj = Object.assign({}, obj)

  Object.keys(obj).forEach(key => {
    if (!arrProps.includes(key)) {
      delete newObj[key]
    }
  })

  return newObj
}

/**
 * Confronta um objeto contra um array de objetos para
 * verificar se ele corresponde a um deles, utilizando
 * um conjunto de atributos
 * @param {object} obj Objeto a ser avaliado
 * @param {object[]} dataset Conjunto de registros
 * @param {string[]} keys Atributos que serão usados para comparação. Se omitido, todos os atributos serão comparados.
 */
function _match (obj, dataset, keys) {
  let matchedObjects = []
  for (let index = 0; index < dataset.length; index++) {
    matchedObjects = dataset.some(
      row => !keys.some(key => row[key.toUpperCase()] != obj[key.toUpperCase()])
    )
  }
  return matchedObjects
}

/**
 * Cria um novo offhire já com um determinado status
 * @param {import('./Offhire').OffhireStatus} status Status do novo offhire
 */
function _newOffhireWithStatus (data, status) {
  const columns = [
    'EMBARCACAO_ID',
    'VIAGEM_ID',
    'ESCALA_PORTO_ID',
    'PONTO_OPERACIONAL_ID',
    'DATA_INICIO',
    'DATA_FIM'
  ]

  // Verifica se o offhire já foi registrado
  if (data['OFFHIRE_ID'] === undefined) {
    const insertData = _selectProps(data, columns)

    // Adiciona o status inicial do Offhire
    insertData['STATUS_OFFHIRE_ID'] = status

    _dispatch(fetchDataPending())

    // store.dispatch(fetchDataPending())
    offhireAPI.insert(
      insertData,
      successData => {
        const newOffhire = successData
        let newData = store.getState().data
        let matchedIndex = -1
        for (let index = 0; index < newData.length; index++) {
          const matchWithNew = !columns.some(
            colName =>
              newData[index][colName.toUpperCase()] !=
              newOffhire[colName.toUpperCase()]
          )
          if (matchWithNew === true) {
            matchedIndex = index
            break
          }
        }

        newData[matchedIndex] = Object.assign(
          {},
          { ...newData[matchedIndex], ...newOffhire }
        )
        _dispatch(fetchDataSuccess(newData))
      },
      errorData => console.log(errorData)
    )
  }
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

const _formSubmit = async values => {
  await sleep(300)
  // window.alert(JSON.stringify(values, 0, 2))
  console.log(JSON.stringify(values, 0, 2))
}

const _methods = {
  communicateOffhire: function (data) {
    _dispatch(
      openModal({
        id: uuid.v4(),
        title: 'Comunicar Offhire',
        data,
        actions: {
          Cancelar: 'cancel',
          Salvar: 'submit'
        },
        form: OffhireCommunicateForm,
        width: 'sm',
        onSubmit: _formSubmit
      })
    )
  },
  communicateOnhire: function (data) {
    _dispatch(
      openModal({
        id: uuid.v4(),
        title: 'Comunicar Onhire',
        data,
        actions: {
          Cancelar: 'cancel',
          Salvar: 'submit'
        },
        form: OffhireStoryForm,
        onSubmit: _formSubmit
      })
    )
  },
  attachFile: function (data) {
    console.log('attachFile executado!')
    _newOffhireWithStatus(data, 'AGUA')
  },
  createReport: function (data) {

    const columns = [
      'EMBARCACAO_ID',
      'VIAGEM_ID',
      'PORTO_ID',
      'ESCALA_PORTO_ID',
      'DATA_FIM',
      'DATA_INICIO',
      'EMBARCACAO_NOME',
      'PORTO_NOME',
      'CHAVE_USUARIO',
      'OBSERVACAO',
      'DURACAO'
    ]

    const initialData = _selectProps(data, columns)


    _dispatch(
      openModal({
        id: uuid.v4(),
        title: 'Criar relato de offhire',
        data: initialData,
        actions: {
          Cancelar: 'cancel',
          Salvar: 'submit'
        },
        form: OffhireStoryForm,
        onSubmit: _formSubmit
      })
    )
  }
}

export default function executeMethod (actionName, offhire, dispatch) {
  if (getAction(actionName) && _methods[actionName]) {
    _dispatch = dispatch
    _methods[actionName](offhire)
  }
}
