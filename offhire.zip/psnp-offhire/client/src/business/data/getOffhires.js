import Axios from 'axios'
import 'regenerator-runtime/runtime'
import Offhire from '../Offhire'

const baseURL = 'http://10.22.218.136:4200/offhires'

const _offhireDataToBusinessMap = {
  EMBARCACAO: 'vessel',
  VIAGEM: 'voyage',
  PO: 'portCall',
  QTP: 'qtp',
  INICIO: 'start',
  FIM: 'end',
  STATUS: 'status',
  DURACAO: 'duration'
}

function _getBusinessObjectsFromData (dataset, objectMap) {
  const businessData = []
  dataset.forEach(element => {
    const businessObject = {}
    Object.keys(element).map(propName => {
      if (typeof objectMap[propName] !== 'undefined') {
        businessObject[objectMap[propName]] = element[propName]
      }
    })
    businessData.push(businessObject)
  })
  return businessData
}

/**
 * Recupera offhires a partir do banco de dados
 * @param {*} filter Filtros
 * @param {function(Offhire[])} resolve Função a executar ao retornar os dados
 */
export async function getOffhiresData (filter, resolve, reject) {
  const urlArray = [baseURL]

  if (filter.myFleet) urlArray.push('myfleet')
  if (filter['EMBARCACAO']) {
    urlArray.push(filter['EMBARCACAO'].split('|')[0])
    if (filter['VIAGEM']) {
      urlArray.push(filter['VIAGEM'])
      if (filter['ESCALA']) {
        urlArray.push(filter['ESCALA'])
      }
    }
  }

  try {
    const result = await Axios.get(urlArray.join('/'));
      return resolve(_getBusinessObjectsFromData(result.data, _offhireDataToBusinessMap));
  }
  catch (result_1) {
    return reject ? reject(result_1) : void 0;
  }
}
