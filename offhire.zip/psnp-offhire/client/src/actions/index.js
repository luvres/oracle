import * as types from './actionTypes'

export const changeProfile = value => ({
  type: types.CHANGE_PROFILE,
  profile: value
})

export const changeMyFleet = value => ({
  type: types.CHANGE_FLEET_FILTER,
  myFleetOnly: value
})

export const fetchDataPending = () => {
  return {
    type: types.FETCH_DATA_PENDING
  }
}

export const fetchDataSuccess = data => {
  return {
    type: types.FETCH_DATA_SUCCESS,
    data
  }
}

export const fetchDataError = error => {
  return {
    type: types.FETCH_DATA_ERROR,
    error
  }
}

export const businessPending = () => {
  return {
    type: types.BUSINESS_PENDING
  }
}

export const businessSuccess = data => {
  return {
    type: types.BUSINESS_SUCCESS
  }
}

export const businessError = error => {
  return {
    type: types.BUSINESS_ERROR,
    businessError: error
  }
}

export const showSnack = message => {
  return {
    type: types.SHOW_SNACK,
    snackShow: true,
    message
  }
}

export const hideSnack = () => {
  return {
    type: types.HIDE_SNACK,
    snackShow: false
  }
}
export const openModal = (obj) => {
  return {
    type: types.OPEN_MODAL,
    obj
  }
}
export const closeModal = (obj) => {
  return {
    type: types.CLOSE_MODAL,
    obj
  }
}

