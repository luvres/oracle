import React, { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import FleetRadioGroup from '../../components/presentation/FleetRadioGroup'
import OffhireTable from '../../components/presentation/OffhireTable/OffhireTable'
import OffhireSummaryCard from '../../components/presentation/OffhireSummaryCard/OffhireSummaryCard'
import { Snackbar } from '@material-ui/core'
import timesheetAPI from '../../business/timesheet'
import { hideSnack } from '../../actions'
import EnhancedTable from '../../components/presentation/EnhancedTable'

export default function Home () {
  const myFleet = useSelector(state => state.myFleetOnly)
  const snackMessage = useSelector(state => state.snackMessage)
  const snackShow = useSelector(state => state.snackShow)
  const dispatch = useDispatch()

  useEffect(
    () => {
      timesheetAPI.get({ myFleet }, dispatch)
    },
    [myFleet]
  )

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') return
    dispatch(hideSnack())
  }

  return (
    <div>
      <FleetRadioGroup />
      <OffhireTable />
      {/* <EnhancedTable /> */}
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center'
        }}
        open={snackShow}
        autoHideDuration={2000}
        onClose={handleSnackbarClose}
        message={snackMessage}
      />
    </div>
  )
}
