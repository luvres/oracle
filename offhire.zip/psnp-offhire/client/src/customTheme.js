import { createMuiTheme } from '@material-ui/core'
import { green, red, orange, yellow, lightGreen } from '@material-ui/core/colors';
import { emphasize, rgbToHex } from '@material-ui/core/styles';

const palettePosition = 500

const offhireStatusColors = {
    REGISTRADO: red[palettePosition],
    AGUARDANDO: orange[palettePosition],
    EMANALISE: yellow[palettePosition],
    VALIDADO: lightGreen[palettePosition],
    CONCLUIDO: green[palettePosition]
}

const createThemeObject = function(){
    const theObject = {}
    Object.keys(offhireStatusColors).forEach(key => theObject[key] = {
        backgroundColor: offhireStatusColors[key],
        color: rgbToHex(emphasize(offhireStatusColors[key], 0.95))
    })
    console.log(theObject)
    return theObject
}

export default createMuiTheme({
    palette: {
        statusOffhire: createThemeObject(),
    },
});