import * as React from 'react'
import { OffhireStatus } from '../../../business/Offhire';


export interface OffhireUIStatus {
  /** Identificador do estado do offhire, como consta no banco de dados */
  id: OffhireStatus

  /** Rótulo do estado do offhire */
  label: string;

  /** Texto explicativo do estado do offhire */
  hint: string;

  /** Cor que representa o estado do offhire, em hexadecimal (#f9f9f9, por exemplo) */
  color: string;
}

/** Exibe um "chip" informando o estado do Offhire */
declare const OffhireStatusChip: React.FC<{
  /** Identificador do estado do Offhire */
  statusId: OffhireStatus;
}>;

export default OffhireStatusChip;