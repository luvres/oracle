import React from 'react'
import { Chip, Tooltip, Icon } from '@material-ui/core'
import { emphasize } from '@material-ui/core/styles'
import { OffhireUIStatus } from './OffhireStatusChip'



/** Atributos de exibição para cada estado de um Offhire
 * @type {OffhireUIStatus[]}
*/
const _statusMap = [
  {
    id: 'REGI',
    label: 'Registrado',
    color: '#f44336',
    hint:
      'Registrado no timesheet mas ainda não analisado por um operador.'
  },
  {
    id: 'AGUA',
    label: 'Aguardando análise',
    color: '#ff9800',
    hint:
      'Operador assumiu o tratamento deste offhire, porém, não iniciou a análise.'
  },
  {
    id: 'EMAN',
    label: 'Em análise',
    color: '#ffeb3b',
    hint:
      'Operador solicitou o Certificado de Offhire e agora aguarda o retorno.'
  },
  {
    id: 'VALI',
    label: 'Validado',
    color: '#8bc34a',
    hint:
      'Offhire foi validado pelo gestor do contrato.'
  },
  {
    id: 'PROV',
    label: 'Provisionado',
    color: '#4caf50',
    hint:
      'Provisionado para dedução'
  },
  {
    id: 'CANC',
    label: 'Cancelado',
    color: '#4caf50',
    hint:
      'Análise concluída e offhire cancelado.'
  },
  {
    id: 'CONC',
    label: 'Concluído',
    color: '#4caf50',
    hint:
      'Análise concluída e offhire enviado para dedução.'
  },
]

export default function OffhireStatusChip (props) {
  const { statusId } = props
  const statusUI = _statusMap.find(item => item.id === statusId)

  const chipStyle = {
    backgroundColor: statusUI.color,
    color: emphasize(statusUI.color, 0.95)
  }

  return <Tooltip title={statusUI.hint} placement='top'><Chip label={statusUI.label} style={chipStyle} size='small' /></Tooltip>
}