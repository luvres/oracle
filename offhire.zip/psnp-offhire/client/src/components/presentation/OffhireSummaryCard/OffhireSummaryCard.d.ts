import * as React from 'react'
import { Offhire } from '../../../business/Offhire';



export type OffhireSummaryCardProps = {
  /** Conjunto de offhires */
  offhires: Offhire[];

}

/** Exibe um card com um resumo dos Offhires, por estado */
declare const OffhireSummaryCard: React.FC<OffhireSummaryCardProps>;

export default OffhireSummaryCard;