import React from 'react'
import PropTypes from 'prop-types'
import { makeStyles } from '@material-ui/core/styles'
import Typography from '@material-ui/core/Typography'

const useStyles = makeStyles(theme => ({
  root: {
    textAlign: "center",
    height: "100%"
  },
  indicadorValor: {
    fontWeight: "bold",
    fontSize: "3em",
    lineHeight: "1.3"
  },
  indicadorLabel: {

  }
}));

/**
 * 
 * @param {import('./OffhireSummaryInfo').OffhireSummaryInfoProps} props 
 */
export default function OffhireSummaryInfo(props) {
  const classes = useStyles();

  const { value, label, color, orientation } = props

  return (
    <div className={classes.root}>
      <Typography variant="subtitle1" className={classes.indicadorValor} style={color ? {color} : null}>{value}</Typography>
      <Typography variant="subtitle2" className={classes.indicadorLabel} style={color ? {color} : null}>{label}</Typography>
    </div>
  )
}