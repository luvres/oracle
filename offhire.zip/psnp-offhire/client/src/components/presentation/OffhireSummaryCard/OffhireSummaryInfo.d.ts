import * as React from 'react'
import { Offhire } from '../../../business/Offhire';



export type OffhireSummaryInfoProps = {
    /**Valor do indicador */
    value: number | string,
  
    /**Título do indicador */
    label: string,
  
    /**Cor do indicador */
    color: string,
  
    /**Orientação */
    orientation: 'horizontal' | 'vertical'
}

/** Item de informação em um resumo de dados de Offhires */
declare const OffhireSummaryInfo: React.FC<OffhireSummaryInfoProps>;

export default OffhireSummaryInfo;