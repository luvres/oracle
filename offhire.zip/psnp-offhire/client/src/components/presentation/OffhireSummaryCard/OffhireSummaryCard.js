import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import { Grid, Card, CardContent} from '@material-ui/core'
import { blue } from '@material-ui/core/colors'
import OffhireSummaryInfo from './OffhireSummaryInfo'
import { useSelector } from 'react-redux'

const useStyles = makeStyles(theme => ({
  root: {
    textAlign: 'center'
  },
  indicadorValor: {
    fontWeight: 'bold',
    fontSize: '3em',
    lineHeight: '1.3'
  },
  indicadorLabel: {}
}))

/**
 *
 * @param {import('./OffhireSummaryCard').OffhireSummaryCardProps} props
 */
export default function OffhireSummaryCard (props) {
  const classes = useStyles()

  // Os dados já foram recuperados estão na store
  const storeDataset = useSelector(state => state.data)
  const profile = useSelector(state => state.profile)

  // Se o perfil do usuário atual for GCA, considera somente os offhires
  // da aplicação, sem os eventos do SIGO
  const localDataset =
    profile === 'GCA'
      ? storeDataset.filter(row => row['OFFHIRE_ID'] != undefined)
      : storeDataset


  const countStatus = status =>
    localDataset.filter(element => element.STATUS_OFFHIRE_ID === status).length

  const summaryItems =
    localDataset && localDataset.length > 0
      ? [
        {
          label: 'Registrado',
          count: countStatus('REGI'),
          color: blue[500]
        },
        {
          label: 'Aguardando análise',
          count: countStatus('AGUA'),
          color: 'primary'
        },
        {
          label: 'Em análise',
          count: countStatus('EMAN'),
          color: 'primary'
        },
        {
          label: 'Validado',
          count: countStatus('VALI'),
          color: 'primary'
        },
        {
          label: 'Concluído',
          count: countStatus('CONC'),
          color: 'primary'
        }
      ]
      : []

  return summaryItems.length > 0 ? (
    <Card className={classes.card}>
      <CardContent>
        <Grid container direction='row' alignItems='center'>
          {summaryItems.map((item, key) => (
            <Grid key={key} item lg sm>
              <OffhireSummaryInfo
                value={item.count}
                label={item.label}
                color={item.color}
                orientation='horizontal'
              />
            </Grid>
          ))}
        </Grid>
      </CardContent>
    </Card>
  ) : null
}
