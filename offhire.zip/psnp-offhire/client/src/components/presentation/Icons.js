import React from "react";
import PropTypes from "prop-types";

/**
 * @typedef {object} LogoBRHorizontal
 * @prop {number} [width=120] Largura do ícone, em pixels.
 * @prop {boolean} [grayedOut=false] Se igual a *true* exibe o ícone em cinza esmaecido *
 * @prop {boolean} [aspectRatio=5.136986301369863] Taxa de proporção entre largura e altura
 * @extends {React.Component<LogoBRHorizontal>}
 */

export class LogoBRHorizontal extends React.Component {
  static propTypes = {
    width: PropTypes.number,
    aspectRatio: PropTypes.number,
    grayedOut: PropTypes.bool
  };

  static defaultProps = {
    width: 120,
    aspectRatio: 5.136986301369863
  };

  render() {
    return (
      <svg
        x="0px"
        y="0px"
        width={`${this.props.width}px`}
        height={`${this.props.width / this.props.aspectRatio }px`}
        viewBox="0 0 120 23.36"        
      >
        <polygon
            fill-rule="evenodd"
            clip-rule="evenodd"
            fill="#FDC82F"
            points="0.003,5.676 23.433,5.676 23.433,0 0.003,0 0.003,5.676"
        />
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            fill="#008542"
            d="M48.578,17.216h-7.231l2.457-8.646h7.059l-0.575,2.006h-4.214
                l-0.357,1.244h3.576l-0.575,2.021h-3.576l-0.389,1.353h4.4L48.578,17.216L48.578,17.216z M0.003,23.36h23.43V8.515H0.003V23.36
                L0.003,23.36z M37.229,14.51L37.229,14.51c-0.155,0.016-0.311,0.016-0.466,0.016h-1.431l-0.762,2.69h-2.845l2.472-8.645h3.031v0
                h1.135c2.487,0,3.358,1.135,2.861,2.908C40.726,13.234,39.435,14.37,37.229,14.51L37.229,14.51z M37.229,10.576L37.229,10.576
                h-0.777l-0.53,1.924l1.306,0.004l0,0c0.59-0.031,1.088-0.311,1.29-1.011c0.218-0.809-0.653-0.917-1.259-0.917H37.229L37.229,10.576z
                M105.613,14.277h0.901l-0.031-3.11l-0.87,1.524l-0.887,1.586H105.613L105.613,14.277z M105.613,8.85l0.186-0.28h2.893l0.637,8.646
                h-2.83v-1.135h-0.886h-1.944l-0.653,1.135h-2.613h-0.17l0.17-0.265L105.613,8.85L105.613,8.85z M119.964,11.074
                c0.219-1.508-0.528-2.737-2.923-2.737c-2.177,0-4.027,0.917-4.541,2.768c-0.948,3.296,4.292,2.395,3.918,3.717
                c-0.108,0.404-0.653,0.637-1.353,0.637c-0.28,0-0.56-0.078-0.746-0.218c-0.203-0.155-0.312-0.373-0.28-0.684h-2.721
                c-0.374,1.555,0.731,2.892,3.016,2.892c2.379,0,4.338-0.979,4.898-2.985c0.901-3.141-4.308-2.348-3.935-3.639
                c0.078-0.311,0.405-0.498,1.042-0.498c0.264,0,0.513,0.047,0.684,0.156c0.171,0.109,0.28,0.295,0.233,0.591H119.964L119.964,11.074z
                M100.403,11.198c0.032-0.063,0.047-0.109,0.063-0.171c0.186-0.653,0.186-1.182-0.063-1.571C100.03,8.85,99.082,8.57,97.324,8.57
                h-0.948h-3.141l-2.457,8.646h2.83l0.87-3.017h0.856c0.528,0,0.855,0.062,1.042,0.202c0.295,0.218,0.249,0.623,0.047,1.306
                c-0.016,0.063-0.031,0.109-0.047,0.156c-0.187,0.684-0.249,1.182-0.233,1.353h0.233h2.644l0.062-0.265
                c-0.327,0-0.187-0.373,0.14-1.508c0.498-1.742,0-1.959-0.809-2.302C99.439,12.877,100.108,12.116,100.403,11.198L100.403,11.198z
                M96.376,12.302c0.731-0.046,1.182-0.28,1.337-0.824c0.17-0.606-0.233-0.902-0.886-0.902h-0.451h-0.871l-0.498,1.726h1.12
                C96.221,12.302,96.298,12.302,96.376,12.302L96.376,12.302z M85.631,17.2c1.959-0.109,3.406-0.809,3.903-2.581
                c0.264-0.949,0-1.757-0.871-1.991c0.653-0.342,1.415-0.995,1.664-1.881c0.482-1.726-0.933-2.177-2.876-2.177h-1.82h-2.332
                l-2.457,8.646h4.229C85.258,17.216,85.444,17.216,85.631,17.2L85.631,17.2z M85.631,10.576h0.933c0.606,0,1.15,0.016,0.964,0.7
                c-0.14,0.498-0.622,0.746-1.197,0.746h-0.7h-0.466l0.405-1.446H85.631L85.631,10.576z M85.631,13.608
                c0.886,0,1.54,0.046,1.322,0.792c-0.171,0.623-0.684,0.778-1.322,0.793c-0.046,0-0.093,0-0.14,0h-1.229l0.451-1.586h0.902
                C85.616,13.608,85.616,13.608,85.631,13.608L85.631,13.608z M75.494,15.21c0.839-0.327,1.399-1.229,1.71-2.364
                c0.342-1.182,0.218-2.426-1.042-2.395c-0.249,0-0.466,0.047-0.668,0.125c-0.887,0.357-1.431,1.384-1.679,2.27
                c-0.327,1.104-0.374,2.488,0.979,2.488C75.042,15.334,75.275,15.288,75.494,15.21L75.494,15.21z M75.494,8.477
                c0.42-0.093,0.855-0.14,1.29-0.14c3.095,0,3.919,2.224,3.265,4.509c-0.699,2.442-2.503,3.997-4.555,4.463
                c-0.42,0.093-0.855,0.14-1.306,0.14c-2.706,0-4.043-1.679-3.219-4.633C71.622,10.545,73.363,8.943,75.494,8.477L75.494,8.477z
                M65.526,15.863c0.016-0.047,0.031-0.093,0.046-0.156c0.203-0.684,0.25-1.088-0.046-1.306c-0.187-0.14-0.513-0.202-1.042-0.202
                H63.63l-0.84,3.017h-2.52h-0.326l0.326-1.135l2.13-7.51h3.125h0.948c2.893,0,3.607,0.777,3.142,2.457
                c-0.296,0.995-0.964,1.834-2.053,2.114c0.808,0.342,1.306,0.56,0.808,2.302c-0.326,1.135-0.466,1.508-0.124,1.508l-0.078,0.265
                h-2.644h-0.233C65.277,17.045,65.355,16.547,65.526,15.863L65.526,15.863z M65.526,12.302c0.731-0.046,1.182-0.28,1.337-0.824
                c0.17-0.606-0.233-0.902-0.887-0.902h-0.451h-0.871l-0.498,1.726h1.119C65.371,12.302,65.449,12.302,65.526,12.302L65.526,12.302z
                M60.271,9.705l0.327-1.135h-0.327h-7.619l-0.637,2.27h2.55l-1.82,6.375h2.831l1.819-6.375h2.55L60.271,9.705L60.271,9.705z"
            />
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            fill="#FFFFFF"
            d="M23.434,8.514V5.673H0v2.841h4.509l-2.499,8.642h5.114
                c2.216,0,2.602-0.518,3.051-0.895c0.601-0.504,0.922-1.702,0.653-2.536c-0.191-0.59-0.749-0.947-0.81-0.964
                c0.692-0.321,1.095-1.025,1.145-1.129c0.257-0.534,0.456-1.501-0.183-2.28C10.45,8.705,9.419,8.527,8.67,8.514h5.475l-2.507,8.66
                h2.538l0.927-3.283h1.45c1.053,0,0.958,0.656,0.983,0.938l0.083,2.415l2.356-0.001c0,0-0.106-2.709-0.115-2.908
                c-0.031-0.696-0.492-1.01-0.886-1.01c0.755-0.204,1.41-0.889,1.672-1.329c0.302-0.507,0.529-1.313,0.23-2.113
                c-0.434-1.162-1.551-1.355-2.333-1.369H23.434L23.434,8.514z M16.118,10.255h1.845c0.875,0,0.91,0.595,0.91,0.764
                c0,0.395-0.348,1.172-1.41,1.172h-1.88C15.582,12.192,16.107,10.303,16.118,10.255L16.118,10.255z M5.584,13.508h1.688
                c0.827,0,0.874,0.225,0.988,0.417c0.113,0.191,0.061,0.595-0.018,0.734c-0.099,0.175-0.265,0.717-1.323,0.717H5.044
                C5.044,15.375,5.583,13.51,5.584,13.508L5.584,13.508z M6.508,10.245h1.954c0.388,0,0.739,0.249,0.739,0.66
                c0,0.554-0.441,0.941-1.053,0.941H6.057L6.508,10.245L6.508,10.245z"
        />
      </svg>
    );
  }
}

/**
 * @typedef {object} SVGAlertIconProps
 * @prop {string} [width='16px'] Largura do ícone. Ex. 16px
 * @prop {string} [height='16px'] Altura do ícone. Ex. 16px
 * @prop {boolean} [grayedOut=false] Se igual a *true* exibe o ícone em cinza esmaecido *
 * @prop {string} [fillColor] Se fornecido, a figura será exibida na cor especificada, em hexadecimal. Ex.: #CCCCCC.
 * @extends {React.Component<SVGAlertIconProps>}
 */
export class SVGAlertIcon extends React.Component {
  static propTypes = {
    width: PropTypes.string,
    height: PropTypes.string,
    grayedOut: PropTypes.bool
  };

  static defaultProps = {
    width: "16",
    height: "16",
    grayedOut: false,
    fillColor: "#000000"
  };

  render() {
    return (
      <svg
        width={this.props.width + "px"}
        height={this.props.height + "px"}
        viewBox="0 0 16 16"
        y="0px"
        x="0px"
      >
        <path
          style={{
            strokeWidth: 1.12,
            stroke: this.props.grayedOut ? "#909090" : "#000000",
            fill: this.props.grayedOut ? "#dadada" : "#fdc82f"
          }}
          d="m 15.046834,14.082163 c 0.479392,-0.846302 0.482445,-1.854996 0.0061,-2.698176 L 10.271251,2.9147152 C 9.7979675,2.0621672 8.9430037,1.5562591 7.9842222,1.5562591 c -0.9587806,0 -1.8137446,0.5090309 -2.2870281,1.3553333 L 0.90939617,11.390233 C 0.43305928,12.242781 0.43611268,13.25772 0.91858707,14.104022 1.394924,14.940957 2.2468346,15.44374 3.1995085,15.44374 h 9.5511655 c 0.955727,0 1.813745,-0.509029 2.296188,-1.361577 z"
        />
        <path
          style={{
            strokeWidth: 0.03289046,
            fill: this.props.grayedOut ? "#909090" : "#000000"
          }}
          d="m 7.9993202,11.65188 c -0.4473103,0 -0.8222616,0.37495 -0.8222616,0.82226 0,0.44731 0.3749513,0.82226 0.8222616,0.82226 0.430865,0 0.8222615,-0.37495 0.8025272,-0.80252 0.019734,-0.47034 -0.3519279,-0.842 -0.8025272,-0.842 z"
        />
        <path
          style={{
            strokeWidth: 0.03289046,
            fill: this.props.grayedOut ? "#909090" : "#000000"
          }}
          d="M 7.7953993,5.87961 C 7.4040028,5.99143 7.1606134,6.34665 7.1606134,6.77752 c 0.019734,0.25983 0.03618,0.52295 0.055914,0.78279 0.055914,0.99 0.1118276,1.96027 0.1677413,2.95027 0.019734,0.33548 0.279569,0.57887 0.6150517,0.57887 0.3354826,0 0.5986063,-0.25983 0.6150516,-0.5986 0,-0.20392 0,-0.3914 0.019734,-0.59861 0.03618,-0.63478 0.075648,-1.26957 0.1118276,-1.90436 0.019734,-0.41113 0.055914,-0.82226 0.075648,-1.23339 0,-0.14801 -0.019734,-0.27957 -0.075648,-0.41113 C 8.5781922,5.97499 8.1867958,5.78751 7.7953993,5.87961 Z"
        />
      </svg>
    );
  }
}

/**
 * @typedef {'up' | 'down' | 'left' | 'right' } Direction
 */

/**
 * @typedef {object} SVGArrowProps
 * @prop {number} [width=32] Largura do ícone, em pixels.
 * @prop {number} [height=32] Altura do ícone, em pixels.
 * @prop {string} [fillColor] Se fornecido, a figura será exibida na cor especificada, em hexadecimal. Ex.: #CCCCCC.
 * @prop {boolean} [grayedOut=false] Se igual a *true* exibe a figura em cinza esmaecido *
 * @prop {Direction} [direction='down'] Direção da seta
 * @extends {React.Component<SVGArrowProps>}
 */
export class SVGArrow extends React.Component {
  static propTypes = {
    width: PropTypes.number,
    height: PropTypes.number,
    fillColor: PropTypes.string,
    grayedOut: PropTypes.bool,
    direction: PropTypes.oneOf(["up", "down", "left", "right"])
  };

  static defaultProps = {
    width: 16,
    height: 16,
    grayedOut: false,
    fillColor: "#000000",
    direction: "down"
  };

  render() {
    const rotate = {
      up: 180,
      down: 0,
      left: 90,
      right: 270
    };

    return (
      <svg
        x="0px"
        y="0px"
        width={`${this.props.width}px`}
        height={`${this.props.height}px`}
        viewBox="0 0 16 16"
        style={{ marginBottom: "-4px" }}
      >
        <path
          style={{
            fill: this.props.grayedOut ? "#909090" : this.props.fillColor
          }}
          d="M11.2,8V1.3c0-0.2-0.2-0.3-0.3-0.3H5.1C4.9,1,4.8,1.2,4.8,1.3V8H2.7l2.6,3.5L8,15l2.6-3.5L13.3,8H11.2z"
          transform={`rotate(${rotate[this.props.direction]}, 8, 8)`}
        />
      </svg>
    );
  }
}

/**
 * @typedef {object} SVGArrowProps
 * @prop {number} [width=32] Largura do ícone, em pixels.
 * @prop {number} [height=32] Altura do ícone, em pixels.
 * @prop {string} [fillColor] Se fornecido, a figura será exibida na cor especificada, em hexadecimal. Ex.: #CCCCCC.
 * @prop {boolean} [grayedOut=false] Se igual a *true* exibe a figura em cinza esmaecido *
 * @extends {React.Component<SVGArrowProps>}
 */
export class SVGTrash extends React.Component {
  static propTypes = {
    width: PropTypes.number,
    height: PropTypes.number,
    fillColor: PropTypes.string,
    grayedOut: PropTypes.bool
  };

  static defaultProps = {
    width: 16,
    height: 16,
    grayedOut: false,
    fillColor: "#000000"
  };

  render() {
    return (
      <svg
        x="0px"
        y="0px"
        width={`${this.props.width}px`}
        height={`${this.props.height}px`}
        viewBox="0 0 16 16"
        style={{ marginBottom: "-4px" }}
      >
        <g
          style={{
            fill: this.props.grayedOut ? "#909090" : this.props.fillColor
          }}
        >
          <path
            d="M14.6,2.4h-3.3V1.9c0-1-0.8-1.7-1.7-1.7H6.4c-1,0-1.7,0.8-1.7,1.7v0.5H1.4C1.2,2.4,1,2.6,1,2.8s0.2,0.4,0.4,0.4h0.8v10.3
            c0,1.3,1,2.3,2.3,2.3h6.9c1.3,0,2.3-1,2.3-2.3V3.3h0.8c0.2,0,0.4-0.2,0.4-0.4S14.8,2.4,14.6,2.4z M5.6,1.9C5.6,1.4,6,1,6.4,1h3.1
            c0.5,0,0.9,0.4,0.9,0.9v0.5H5.6V1.9z M12.9,13.5c0,0.8-0.7,1.5-1.5,1.5H4.6c-0.8,0-1.5-0.7-1.5-1.5V3.3h9.8L12.9,13.5L12.9,13.5z"
          />
          <path d="M8,13.4c0.2,0,0.4-0.2,0.4-0.4V5.3C8.4,5,8.2,4.8,8,4.8C7.8,4.8,7.6,5,7.6,5.3V13C7.6,13.2,7.8,13.4,8,13.4z" />
          <path d="M5.1,12.9c0.2,0,0.4-0.2,0.4-0.4V5.8c0-0.2-0.2-0.4-0.4-0.4c-0.2,0-0.4,0.2-0.4,0.4v6.8C4.7,12.8,4.9,12.9,5.1,12.9z" />
          <path d="M10.9,12.9c0.2,0,0.4-0.2,0.4-0.4V5.8c0-0.2-0.2-0.4-0.4-0.4s-0.4,0.2-0.4,0.4v6.8C10.4,12.8,10.6,12.9,10.9,12.9z" />
        </g>
      </svg>
    );
  }
}

/*
<div>
  Icons made by
  <a
    href="https://www.flaticon.com/authors/gregor-cresnar"
    title="Gregor Cresnar">Gregor Cresnar
  </a>
  from 
  <a
    href="https://www.flaticon.com/"
    title="Flaticon">www.flaticon.com
  </a>
  is licensed by
  <a
    href="http://creativecommons.org/licenses/by/3.0/"
    title="Creative Commons BY 3.0"
    target="_blank">CC 3.0 BY
  </a>
</div>
*/
