import React from 'react'
import PropTypes from 'prop-types'
export default class Input extends React.Component {
  render () {
    return (
      <div className='form-group'>
        <label htmlFor={this.props.label}>{this.props.text}</label>
        <input
          type={this.props.type}
          className='form-control'
          id={this.props.id}
          value={this.props.value}
          onChange={this.props.handleChange}
          required
        />
      </div>
    )
  }
}

Input.propTypes = {
  label: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  handleChange: PropTypes.func.isRequired
}
