import React from 'react'
import { useDispatch } from 'react-redux'
import { Form } from 'react-final-form'
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle
} from '@material-ui/core'
import { makeStyles } from '@material-ui/styles'
import { closeModal } from '../../../actions'

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  actions: {
    margin: theme.spacing(2)
  },
  grow: {
    flexGrow: 1
  },
  title:{
    backgroundColor: '#008542',
    borderBottom: '2px solid darkgreen',
    color: 'white'
  },
  titleLight:{
    color: '#006298'
  }
}))

export default function FormDialog (props) {
  const { open, data, title, subtitle, onClose, item } = props

  const [opened, setOpened] = React.useState(open)

  const classes = useStyles()

  const _dispatch = useDispatch()

  const actions =
    item.actions &&
    typeof item.actions === 'object' &&
    Object.keys(item.actions).length > 0
      ? item.actions
      : {
        Fechar: 'close'
      }

  const _triggerClose = () => {
    setOpened(false)
  }

  const _handleExited = () => {
    _dispatch(closeModal(item))
  }

  const FormContent = item.form

  return (
    <Dialog
      {...props}
      id={item.id}
      open={opened}
      onClose={_triggerClose}
      onExited={_handleExited}
      aria-labelledby='form-dialog-title'
    >
      <Form
        onSubmit={item.onSubmit}
        initialValues={item.data}
        render={({ handleSubmit, form, submitting, pristine, values }) => (
          <form onSubmit={handleSubmit}>
            <DialogTitle id='form-dialog-title'>{title}</DialogTitle>
            <DialogContent>
              <FormContent data={item.data} />
            </DialogContent>
            <DialogActions className={classes.actions}>
              <Button
                type='button'
                variant='contained'
                onClick={form.reset}
                disabled={submitting || pristine}
              >
                Reiniciar
              </Button>
              <div className={classes.grow} />
              {Object.keys(actions).map((name, key) => {
                return (
                  <Button
                    key={key}
                    onClick={
                      actions[name] != 'submit'
                        ? actions[name] === 'cancel'
                          ? _triggerClose
                          : undefined
                        : undefined
                    }
                    type={actions[name] === 'submit' ? 'submit' : 'button'}
                    disabled={
                      actions[name] === 'submit' || 'cancel'
                        ? submitting
                        : submitting || pristine
                    }
                    color={actions[name] === 'submit' ? 'primary' : undefined}
                    variant='contained'
                  >
                    {name}
                  </Button>
                )
              })}
            </DialogActions>
          </form>
        )}
      />
    </Dialog>
  )
}
