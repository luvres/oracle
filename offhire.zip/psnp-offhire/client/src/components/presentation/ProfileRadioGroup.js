import { makeStyles } from '@material-ui/core/styles'
import React from 'react'
import {
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup
} from '@material-ui/core'
import { green } from '@material-ui/core/colors'
import { useSelector, useDispatch } from 'react-redux'
import * as GlobalActions from '../../actions'

const useStyles = makeStyles(theme => ({
  radio: {
    color: green[200],
    '&$checked': {
      color: green[600]
    }
  }
}))

export default function ProfileRadioGroup () {
  const classes = useStyles()
  const profile = useSelector(state => state.profile)
  const dispatch = useDispatch()
  const handleChange = e =>
    dispatch(GlobalActions.changeProfile(e.target.value))

  return (
    <div className={classes.root}>
      <FormControl component='fieldset'>
        <RadioGroup
          aria-label='position'
          name='position'
          value={profile}
          onChange={handleChange}
          row
        >
          <FormControlLabel
            value='ON'
            control={<Radio color='default' className={classes.radio} />}
            label='ON'
            labelPlacement='start'
          />
          <FormControlLabel
            value='GCA'
            control={<Radio color='default' className={classes.radio} />}
            label='GCA'
            labelPlacement='start'
          />
        </RadioGroup>
      </FormControl>
    </div>
  )
}
