import React, { Component } from 'react';
import SwipeableDrawer from '@material-ui/core/SwipeableDrawer';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core';
import PropTypes from 'prop-types'

class MainDrawer extends Component {
  static defaultProps = {
    classes: PropTypes.object.isRequired
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { open, onClose, onOpen, classes } = this.props
    return (
      <div>
        <SwipeableDrawer open={open} onOpen={onOpen} onClose={onClose} className={classes.drawer} classes={{paper: classes.drawerPaper}}>
          <MenuItem>Menu Item</MenuItem>
          <MenuItem>Menu Item 2</MenuItem>
        </SwipeableDrawer>
      </div>
    );
  }
}
const drawerWidth = '200px';
const styles = theme => ({
  root: {
    display: 'flex'
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    zIndex: 101
  },
  drawerPaper: {
    width: drawerWidth,
  }
})

export default withStyles(styles)(MainDrawer)