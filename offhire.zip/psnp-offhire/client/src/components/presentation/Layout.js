import React from 'react'
import { Route, Switch } from 'react-router-dom';
import { Container } from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles'
import TopBar from '../layout/TopBar'
import Home from '../../pages/home/Home';
import About from '../../pages/about/About';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  flex: {
    flex: 1,
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      left: '50%',
      transform: 'translate(-50%)'
    }
  },
  container: {
    marginTop: theme.spacing(8)
  }
}))



export default function Layout() {
  const classes = useStyles()
  return (
    <div className={classes.root}>
      <TopBar position='fixed'/>
      <Container className={classes.container}>
        <div>
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
          </Switch>
        </div>
      </Container>
    </div>
  )
}
