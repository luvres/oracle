import * as React from 'react'
import { Offhire } from '../../../business/Offhire';


export type OffhireTableProps = {
  /** Conjunto de offhires */
  offhires: Offhire[];

  /** Os dados estão sendo carregados? */
  isLoading: boolean;
}

/** Exibe uma tabela de Offhires */
declare const OffhireTable: React.FC<OffhireTableProps>;

export default OffhireTable;