import React from 'react'
import { useDispatch } from 'react-redux'
import { makeStyles } from '@material-ui/core/styles'
import { Tooltip, IconButton, Icon, Box } from '@material-ui/core'
import { blueGrey } from '@material-ui/core/colors'
import { getActions } from '../../../business/Action'
import { offhireActionNames } from '../../../business/Offhire'
import executeAction from '../../../business/offhireActions'

const useStyles = makeStyles(theme => ({
  root: {
    marginTop: theme.spacing(10),
    width: '100%'
  },
  iconHover: {
    color: blueGrey[500],
    '&:hover': {
      color: blueGrey[700]
    },
    cursor: 'pointer'
  }
}))

/**
 *
 * @param {import('./OffhireActions').OffhireActionsProps} props
 */
export default function OffhireActions (props) {
  const classes = useStyles()

  const { offhire, appearance, onTriggered } = props

  const offhireActions = getActions(offhireActionNames(offhire))

  const dispatch = useDispatch()

  const offhireKey = JSON.stringify({
    EMBARCACAO_ID: offhire.EMBARCACAO_ID,
    VIAGEM_ID: offhire.VIAGEM_ID,
    ESCALA_PORTO_ID: offhire.ESCALA_PORTO_ID,
    PONTO_OPERACIONAL_ID: offhire.PONTO_OPERACIONAL_ID
  })

  const handleClick = function (event) {
    const actionName = event.currentTarget.dataset.actionName

    executeAction(actionName, offhire, dispatch)
  }

  return (
    <Box display='flex' flexDirection='row'>
      {offhireActions.map((action, key) => (
        <Tooltip title={action.label} key={key} placement='top'>
          <IconButton
            aria-label='delete'
            className={classes.iconHover}
            onClick={handleClick}
            data-action-name={action.name}
            data-key-value={offhireKey}
          >
            {typeof action.icon === 'string' ? (
              action.color ? (
                <Icon fontSize='small' style={{ color: action.color }}>
                  {action.icon}
                </Icon>
              ) : (
                <Icon fontSize='small' color='primary'>
                  {action.icon}
                </Icon>
              )
            ) : (
              action.icon
            )}
          </IconButton>
        </Tooltip>
      ))}
    </Box>
  )
}
