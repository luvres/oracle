import * as React from 'react'
import { Offhire } from '../../../business/Offhire';

export type ActionAppearance = 'link' | 'button' | 'menu'

export type OffhireActionsProps = {
  /** Objeto que representa o Offhire */
  offhire: Offhire;

  /** Formato de exibição das ações */
  appearance: ActionAppearance;
}

/** Exibe um conjunto de ações possíveis para um Offhire, de acordo com seu status */
declare const OffhireActions: React.FC<OffhireActionsProps>;

export default OffhireActions;