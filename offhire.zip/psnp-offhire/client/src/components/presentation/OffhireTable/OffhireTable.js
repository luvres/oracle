import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { makeStyles, useTheme } from '@material-ui/core/styles'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import TableFooter from '@material-ui/core/TableFooter'
import TablePagination from '@material-ui/core/TablePagination'
import moment from 'moment'
import { Paper, LinearProgress, IconButton } from '@material-ui/core'
import OffhireActions from './OffhireActions'
import OffhireStatusChip from '../OffhireStatus/OffhireStatusChip'
import OffhireSummaryCard from '../OffhireSummaryCard/OffhireSummaryCard'
import FirstPageIcon from '@material-ui/icons/FirstPage'
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft'
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight'
import LastPageIcon from '@material-ui/icons/LastPage'

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  paper: {
    width: '100%',
    overflowX: 'auto'
  },
  table: {
    minWidth: 650
  },
  tableTitle: {
    // marginBottom: theme.spacing(4),
  }
}))

const useStyles1 = makeStyles(theme => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5)
  }
}))

function TablePaginationActions (props) {
  const classes = useStyles1()
  const theme = useTheme()
  const { count, page, rowsPerPage, onChangePage } = props

  const handleFirstPageButtonClick = event => {
    onChangePage(event, 0)
  }

  const handleBackButtonClick = event => {
    onChangePage(event, page - 1)
  }

  const handleNextButtonClick = event => {
    onChangePage(event, page + 1)
  }

  const handleLastPageButtonClick = event => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1))
  }

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label='primeira página'
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton
        onClick={handleBackButtonClick}
        disabled={page === 0}
        aria-label='voltar'
      >
        {theme.direction === 'rtl' ? (
          <KeyboardArrowRight />
        ) : (
          <KeyboardArrowLeft />
        )}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label='avançar'
      >
        {theme.direction === 'rtl' ? (
          <KeyboardArrowLeft />
        ) : (
          <KeyboardArrowRight />
        )}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label='última página'
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  )
}

export default function OffhireTable () {
  const classes = useStyles()

  // Os dados já foram recuperados estão na store
  const storeDataset = useSelector(state => state.data)

  const pending = useSelector(state => state.pending)
  const profile = useSelector(state => state.profile)

  const [page, setPage] = React.useState(0)
  const [rowsPerPage, setRowsPerPage] = React.useState(5)

  // Definição das colunas a exibir na tabela, relacionando ao campo
  // da consulta com o nome da coluna.
  // ATENÇÃO: A tabela exibirá as colunas na ordem em que se apresentam aqui.
  const COLUMN =
    profile === 'ON'
      ? {
        EMBARCACAO_NOME: 'Embarcação',
        VIAGEM_ID: 'Viagem',
        PORTO_ID: 'Escala Porto',
        PONTO_OPERACIONAL_ID: 'Ponto operacional',
        DATA_GRAVACAO: 'Registrado em',
        DATA_INICIO: 'Início',
        DATA_FIM: 'Fim',
        DURACAO: 'Duração (h)',
        STATUS_OFFHIRE_ID: 'Status'
      }
      : {
        EMBARCACAO_NOME: 'Embarcação',
        VIAGEM_ID: 'Viagem',
        PORTO_ID: 'Escala Porto',
        PONTO_OPERACIONAL_ID: 'Ponto operacional',
        DATA_QTP: 'QTP',
        DATA_INICIO: 'Início',
        STATUS_OFFHIRE_ID: 'Status'
      }

  // Se o perfil do usuário atual for GCA, exibe somente os offhires
  // da aplicação, sem os eventos do SIGO
  const localDataset =
    profile === 'GCA'
      ? storeDataset.filter(row => row['OFFHIRE_ID'] != undefined)
      : storeDataset

  const emptyRows =
    rowsPerPage -
    Math.min(rowsPerPage, localDataset.length - page * rowsPerPage)

  const getHeaders = function () {
    const columnNames = []
    if (localDataset && localDataset.length > 0) {
      Object.keys(COLUMN).map(name => {
        localDataset[0][name] ? columnNames.push(name) : null
      })
    }
    return columnNames
  }

  const getCellContent = function (row, column) {
    let cellContent = null

    switch (column) {
      case 'DATA_INICIO':
      case 'DATA_FIM':
      case 'DATA_GRAVACAO':
        cellContent =
          row[column] != null
            ? moment(row[column]).format('DD/MM/YYYY HH:mm')
            : null
        break
      case 'DURACAO':
        cellContent =
          row[column] != null ? Number(row[column]).toFixed(1) : null
        break
      case 'STATUS_OFFHIRE_ID':
        cellContent = <OffhireStatusChip statusId={row[column]} />
        break
      default:
        cellContent = row[column]
    }

    return <TableCell key={column}>{cellContent}</TableCell>
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPage(0)
  }

  const headers = getHeaders()

  return localDataset && headers.length > 0 ? (
    <div className={classes.root}>
      <OffhireSummaryCard />
      <p className={classes.tableTitle} />
      <Paper className={classes.paper}>
        {pending ? <LinearProgress color='secondary' /> : null}
        <Table className={classes.table}>
          <TableHead>
            <TableRow>
              {headers.map((header, index) => (
                <TableCell key={index}>{COLUMN[header]}</TableCell>
              ))}
              <TableCell key={headers.length + 1}>Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowsPerPage > 0
              ? localDataset.slice(
                page * rowsPerPage,
                page * rowsPerPage + rowsPerPage
              )
              : localDataset
            ).map((row, index) => {
              const rowKey = [
                index,
                row['EMBARCACAO_ID'],
                row['VIAGEM_ID'],
                row['PORTO_ID']
              ].join('_')
              return (
                <TableRow key={rowKey}>
                  {headers.map(columnName => getCellContent(row, columnName))}
                  <TableCell>
                    <OffhireActions
                      offhire={row}
                      appearance='button'
                    />
                  </TableCell>
                </TableRow>
              )
            })}

            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={headers.length + 2} />
              </TableRow>
            )}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TablePagination
                labelDisplayedRows={({ from, to, count }) =>
                  `Exibindo ${from}-${to === -1 ? count : to} de ${count}`
                }
                labelRowsPerPage={'Linhas por página:'}
                rowsPerPageOptions={[5, 10, 25, { label: 'Todos', value: -1 }]}
                colSpan={headers.length + 2}
                count={localDataset.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: { 'aria-label': 'linhas por página' },
                  native: true
                }}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
              />
            </TableRow>
          </TableFooter>
        </Table>
      </Paper>
    </div>
  ) : null
}
