import { makeStyles } from '@material-ui/core/styles'
import React, { useEffect } from 'react'
import PropTypes from 'prop-types'
import Typography from '@material-ui/core/Typography'
import { FormControl, FormLabel, RadioGroup, FormControlLabel, Radio } from '@material-ui/core'
import { useSelector, useDispatch } from 'react-redux'
import * as GlobalActions from '../../actions'

//import { useSelector } from 'react-redux'

const useStyles = makeStyles(theme => ({
  root: {
      marginTop: theme.spacing(10),
      width: '100%',
  }
}));


export default function FleetRadioGroup({
  onChange
}) {
  const classes = useStyles();

  //const myFleetOnly = useSelector(state => state.myFleetOnly)
  // const [value, setValue] = React.useState('N');

  const myFleetOnly = useSelector(state => state.myFleetOnly)
  const dispatch = useDispatch()
  const handleChange = e =>
    dispatch(GlobalActions.changeMyFleet(e.target.value))


  // const handleChange = event => {
  //   onChange ? onChange(event.target.value) : null
  //   setValue(event.target.value);
  // };

  // useEffect(() => {
  //   onChange ? onChange(value) : null
  // });



  return (
    <div className={classes.root}>
      <FormControl component="fieldset">
      <RadioGroup aria-label="position" name="position" value={myFleetOnly} onChange={handleChange} row>
          <FormControlLabel
            value={'S'}
            control={<Radio color="primary" />}
            label="Minha frota"
            labelPlacement="start"
          />
          <FormControlLabel
            value={'N'}
            control={<Radio color="primary" />}
            label="Todos os navios"
            labelPlacement="start"
          />
        </RadioGroup>        
      </FormControl>
  </div>
  )
}

FleetRadioGroup.propTypes = {
  onChange: PropTypes.func
}