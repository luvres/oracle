import * as React from 'react'

export type FetchDataProps = {

  /** URL para chamada da API REST */
  restURL: string;

  /** Parâmetros da requisição */
  params: Object;

  /** Ação executada ao retornar os dados com sucesso */
  onResolve(
    /** Dados retornados */
    data: any,
    /** Mensagem de feedback */
    message:string
  ): Function;

  /** Ação executada quando ocorre algum erro na requisição */
  onReject(rejectionData: PromiseRejectionEvent): Function;

  /** Modo de apresentação do erro */
  showErrorMode: 'body' | 'dialog'

  /** Exibir feedback de carregamento ao usuário? */
  showLoading?:  true | false
}

/** Recupera dados a partir do banco de dados e executa ações de acordo com o resultado */
declare const FetchData: React.FC<FetchDataProps>;

export default FetchData;