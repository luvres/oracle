import { useEffect } from 'react'
import Axios from 'axios'
import 'regenerator-runtime/runtime'
import { useDispatch } from 'react-redux'
import {
  fetchDataPending,
  fetchDataSuccess,
  fetchDataError
} from '../../actions'

const baseURL = 'http://10.22.218.136:3000/api/sigo/timesheet'

const _offhireDataToBusinessMap = {
  EMBARCACAO: 'vessel',
  VIAGEM: 'voyage',
  PO: 'portCall',
  QTP: 'qtp',
  INICIO: 'start',
  FIM: 'end',
  STATUS: 'status',
  DURACAO: 'duration'
}

function _getBusinessObjectsFromData (dataset, objectMap) {
  const businessData = []
  dataset.forEach(element => {
    const businessObject = {}
    Object.keys(element).map(propName => {
      if (typeof objectMap[propName] !== 'undefined') {
        businessObject[objectMap[propName]] = element[propName]
      }
    })
    businessData.push(businessObject)
  })
  return businessData
}

/**
 *
 * @param {import('./FetchData').FetchDataProps} props
 */
export default function FetchData ({
  onResolve,
  onReject,
  params,
  restURL,
  sortBy,
  sortDirection = 'asc',
  showErrorMode = 'body',
  showLoading = true
}) {
  const dispatch = useDispatch()
  // useEffect(() => {
    const urlArray = [baseURL]
    if (params && params.myFleet) {
      params.myFleet === true ? urlArray.push('myfleet') : void 0
    }
    dispatch(fetchDataPending())

    Axios.get(urlArray.join('/'))
      .then(result => {
        const data = _getBusinessObjectsFromData(
          result.data.rows,
          _offhireDataToBusinessMap
        )

        dispatch(fetchDataSuccess(data))
        onResolve ? onResolve(data, 'Dados obtidos com sucesso!') : void 0
      })
      .catch(err => console.log(err))
  // }, [])

  return null
}
