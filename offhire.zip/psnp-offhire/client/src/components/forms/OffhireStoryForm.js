import React from 'react'
import { Field } from 'react-final-form'
import {
  TextField,
  Checkbox,
  Radio,
  Select,
  Input
} from 'final-form-material-ui'
import {
  Grid,
  FormControlLabel,
  InputBase,
  Typography
} from '@material-ui/core'
import { makeStyles } from '@material-ui/styles'

// Pickers
import DateFnsUtils from '@date-io/date-fns'
import {
  MuiPickersUtilsProvider,
  TimePicker,
  DatePicker
} from '@material-ui/pickers'
import format from 'date-fns/format'
import formatDistance from 'date-fns/formatDistance'
import ptBRLocale from 'date-fns/locale/pt-BR'

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  actions: {
    margin: theme.spacing(2)
  },
  grow: {
    flexGrow: 1
  },
  staticLabel: {
    color: 'rgba(0, 0, 0, 0.54)'
  },
  staticField: {
    marginBottom: theme.spacing(1),
    fontWeight: 'bold',
    lineHeight: 'inherit'
  }
}))

class LocalizedUtils extends DateFnsUtils {
  getDatePickerHeaderText (date) {
    return format(date, 'd MMMM', { locale: this.locale })
  }
}

function DatePickerWrapper (props) {
  const {
    input: { name, onChange, value, ...restInput },
    meta,
    ...rest
  } = props
  const showError =
    ((meta.submitError && !meta.dirtySinceLastSubmit) || meta.error) &&
    meta.touched

  return (
    <DatePicker
      {...rest}
      name={name}
      helperText={showError ? meta.error || meta.submitError : undefined}
      error={showError}
      inputProps={restInput}
      onChange={onChange}
      format='dd/MM/yyyy'
      value={value === '' ? null : value}
    />
  )
}

function TimePickerWrapper (props) {
  const {
    input: { name, onChange, value, ...restInput },
    meta,
    ...rest
  } = props
  const showError =
    ((meta.submitError && !meta.dirtySinceLastSubmit) || meta.error) &&
    meta.touched

  return (
    <TimePicker
      {...rest}
      name={name}
      helperText={showError ? meta.error || meta.submitError : undefined}
      error={showError}
      inputProps={restInput}
      onChange={onChange}
      value={value === '' ? null : value}
    />
  )
}
let classes

const StaticField = props => (
  <div>
    <Typography variant='caption' className={classes.staticLabel}>
      {props.label}
    </Typography>
    <Typography variant='subtitle1' className={classes.staticField}>
      {props.input.value}
    </Typography>
  </div>
)

const formatDate = value =>
  value
    ? format(new Date(value), 'dd/MM/yyyy HH:mm', { locale: ptBRLocale })
    : ''

export function OffhireStoryForm (props) {
  const { data } = props
  classes = useStyles()

  return (
    <Grid container alignItems='flex-start' spacing={2}>
      <Grid item xs={4}>
        <Field name='EMBARCACAO_NOME' label='Embarcação'>
          {StaticField}
        </Field>
        <Field name='VIAGEM_ID' label='Viagem'>
          {StaticField}
        </Field>
        <Field name='PORTO_NOME' label='Porto'>
          {StaticField}
        </Field>
      </Grid>
      <Grid item xs={4}>
        <Field name='DATA_INICIO' label='Início' format={formatDate}>
          {StaticField}
        </Field>
        <Field name='DATA_FIM' label='Fim' format={formatDate}>
          {StaticField}
        </Field>
        <Field
          name='DURACAO'
          label='Duração'
          format={() =>
            formatDistance(
              new Date(data['DATA_INICIO']),
              new Date(data['DATA_FIM']),
              { locale: ptBRLocale }
            )
          }
        >
          {StaticField}
        </Field>
      </Grid>
      <Grid item xs={4}>
        <Field name='OBSERVACAO' label='Observações'>
          {StaticField}
        </Field>
      </Grid>
      <Grid item xs={12}>
        <Field
          name='RELATO_TEXTO'
          fullWidth
          required
          component={TextField}
          multiline
          label='Relato'
        />
      </Grid>
      <Grid item xs={12}>
        <FormControlLabel
          label='Employed'
          control={
            <Field name='employed' component={Checkbox} type='checkbox' />
          }
        />
      </Grid>
      <MuiPickersUtilsProvider utils={LocalizedUtils} locale={ptBRLocale}>
        <Grid item xs={6}>
          <Field
            name='defaultDate'
            component={DatePickerWrapper}
            fullWidth
            margin='normal'
            label='Rendez-vous'
            clearLabel='Limpar'
            cancelLabel='Cancelar'
          />
        </Grid>
        <Grid item xs={6}>
          <Field
            name='alarm'
            component={TimePickerWrapper}
            fullWidth
            margin='normal'
            label='Alarm'
          />
        </Grid>
      </MuiPickersUtilsProvider>
    </Grid>
  )
}
