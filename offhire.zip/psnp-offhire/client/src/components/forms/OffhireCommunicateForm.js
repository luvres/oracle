import React from 'react'
import { Field } from 'react-final-form'
import {
  TextField,
  Checkbox,
  Radio,
  Select,
  Input
} from 'final-form-material-ui'
import { Grid, FormControlLabel } from '@material-ui/core'
import { makeStyles } from '@material-ui/styles'

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  actions: {
    margin: theme.spacing(2)
  },
  grow: {
    flexGrow: 1
  }
}))

export function OffhireCommunicateForm (props) {

  return (
    <Grid container alignItems='flex-start' spacing={2}>
      <Grid item xs={6}>
        <Field
          fullWidth
          required
          name='firstName'
          component={TextField}
          type='text'
          label='First Name'
        />
      </Grid>
      <Grid item xs={6}>
        <Field
          fullWidth
          required
          name='lastName'
          component={TextField}
          type='text'
          label='Last Name'
        />
      </Grid>
      <Grid item xs={12}>
        <Field
          name='email'
          fullWidth
          required
          component={TextField}
          type='email'
          label='Email'
        />
      </Grid>
      <Grid item xs={12}>
        <FormControlLabel
          label='Employed'
          control={
            <Field name='employed' component={Checkbox} type='checkbox' />
          }
        />
      </Grid>
    </Grid>
  )
}
