import AppBar from '@material-ui/core/AppBar'
import IconButton from '@material-ui/core/IconButton'
import { makeStyles } from '@material-ui/core/styles'
import Toolbar from '@material-ui/core/Toolbar'
import MenuIcon from '@material-ui/icons/Menu'
import React, { Component } from 'react'
import Typography from '@material-ui/core/Typography'
// import AppBarMenuItem from '../presentation/AppBarMenuItem'
// import Grid from '@material-ui/core/Grid'
// import Hidden from '@material-ui/core/Hidden'
import MenuNav from './MenuNav'
import { Switch } from '@material-ui/core'
import ProfileRadioGroup from '../presentation/ProfileRadioGroup'
import { useSelector } from 'react-redux'

const version = process.env.npm_package_version

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%'
  },
  flex: {
    flex: 1,
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      left: '50%',
      transform: 'translate(-50%)'
    }
  },
  grow: {
    flexGrow: 1
  },
  appBar: {
    background: '#008542',
    borderBottom: `solid 3px #FDC82F`,
    zIndex: 100
  },
  appTitle: {
    fontWeight: 500,
    fontSize: '1.3em',
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    listStyleType: 'none',
    margin: 0
  },
  appVersion: {
    fontWeight: 300,
    fontSize: '0.7em'
  },
  toolbar: {
    minHeight: 48,
    [theme.breakpoints.down('sm')]: {
      minHeight: 48
    }
  },
  menuButton: {
    color: `#ffffff`,
    marginLeft: -12,
    marginRight: 10,
    alignSelf: 'center'
  },
  invertedBtn: {
    color: '#21412a',
    backgroundColor: 'transparent',
    border: '2px #21412a solid',
    boxShadow: 'none',
    '&:hover': {
      backgroundColor: '#21412a',
      color: 'white'
    }
  },
  listStyles: {
    display: 'flex',
    margin: 0
  },
  listLi: {
    margin: '0 8px'
  },
  col1: {
    display: 'flex'
  },
  col2: {
    flex: 1
  },
  col2Top: {
    display: 'flex',
    justifyContent: 'flex-end'
  },
  menuList: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    listStyleType: 'none',
    margin: 0
  },
  ulLink: {
    textDecoration: 'none'
  }
}))

export default function TopBar (props) {
  const classes = useStyles()

  const [menuVisible, setMenuVisible] = React.useState(false)

  const pending = useSelector(state => state.pending)

  const toggleMenu = open => event => {
    console.log(event)
    setMenuVisible(typeof open === 'undefined' ? !menuVisible : open)
  }

  return (
    <div className={classes.root}>
      <MenuNav
        open={menuVisible}
        onOpen={toggleMenu(true)}
        onClose={toggleMenu(false)}
      />
      <AppBar className={classes.appBar}>
        <Toolbar className={classes.toolbar}>
          <div className={classes.col1}>
            <IconButton
              className={classes.menuButton}
              aria-label='Menu'
              title='Menu'
              onClick={toggleMenu(true)}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant={'inherit'} className={classes.appTitle}>
              <span>
                Análise de Offhire&nbsp;&nbsp;&nbsp;
                <small className={classes.appVersion}>{version}</small>
              </span>
            </Typography>
          </div>
          <div className={classes.grow} />
          { pending ? <Typography>Carregando...</Typography> : null}
          <ProfileRadioGroup/>
          {/*<Switch value="checkedC" inputProps={{ 'aria-label': 'primary checkbox' }} />*/}

          {/* <Grid
            container
            className={`${classes.col2} ${classes.mobileGridContainer}`}
          >
            <Hidden smDown>
              <Grid item xs={12} style={{ paddingTop: 0 }}>
                <ul className={classes.menuList}>
                  <AppBarMenuItem
                    linkUrl='/academics/ug/majors'
                    content='Degrees'
                    asUrl='/page?type=academicsPages&id=majors'
                  />
                  <AppBarMenuItem
                    toggleDrawer={toggleDrawer}
                    linkId='admissions'
                    content='Admissions'
                  />
                  <AppBarMenuItem
                    content='Tuition & Aid'
                    linkUrl='/sfs/new/costs-and-fees'
                    asUrl='/page?type=sfsPages&id=costs-and-fees'
                  />
                  <AppBarMenuItem
                    toggleDrawer={toggleDrawer}
                    linkId='about'
                    content='About'
                  />
                </ul>
              </Grid>
            </Hidden>
          </Grid> */}
        </Toolbar>
      </AppBar>
    </div>
  )
}
