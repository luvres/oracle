import AppBar from '@material-ui/core/AppBar'
import Grid from '@material-ui/core/Grid'
import Hidden from '@material-ui/core/Hidden'
import IconButton from '@material-ui/core/IconButton'
import { withStyles } from '@material-ui/core/styles'
import Toolbar from '@material-ui/core/Toolbar'
import MenuIcon from '@material-ui/icons/Menu'
import PropTypes from 'prop-types'
import React, { Component } from 'react'
import Typography from '@material-ui/core/Typography'
import AppBarMenuItem from './AppBarMenuItem'

const version = process.env.npm_package_version;

class TopBar extends Component {
  static defaultProps = {
    classes: PropTypes.object.isRequired
  }
  state = {}

  render () {
    const { classes, toggleDrawer } = this.props
    return (
      <div className={classes.root}>
        <AppBar className={classes.appBar}>
          <Toolbar className={classes.toolbar}>
            <div className={classes.col1}>
              <IconButton
                className={classes.menuButton}
                aria-label='Menu'
                title='Menu'
                onClick={toggleDrawer}
              >
                <MenuIcon />
              </IconButton>
              <Typography variant={'inherit'} className={classes.appTitle}>
                <span>
                  Análise de Offhire&nbsp;&nbsp;&nbsp;
                  <small className={classes.appVersion}>{version}</small>
                </span>
              </Typography>
            </div>

            {/*<Grid
              container
              className={`${classes.col2} ${classes.mobileGridContainer}`}
            >
              <Hidden smDown>
                <Grid item xs={12} style={{ paddingTop: 0 }}>
                  <ul className={classes.menuList}>
                    <AppBarMenuItem
                      linkUrl='/academics/ug/majors'
                      content='Degrees'
                      asUrl='/page?type=academicsPages&id=majors'
                    />
                    <AppBarMenuItem
                      toggleDrawer={toggleDrawer}
                      linkId='admissions'
                      content='Admissions'
                    />
                    <AppBarMenuItem
                      content='Tuition & Aid'
                      linkUrl='/sfs/new/costs-and-fees'
                      asUrl='/page?type=sfsPages&id=costs-and-fees'
                    />
                    <AppBarMenuItem
                      toggleDrawer={toggleDrawer}
                      linkId='about'
                      content='About'
                    />
                  </ul>
                </Grid>
              </Hidden>
            </Grid>*/}
          </Toolbar>
        </AppBar>
      </div>
    )
  }
}

const styles = theme => ({
  root: {
    width: '100%'
  },
  flex: {
    flex: 1,
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      left: '50%',
      transform: 'translate(-50%)'
    }
  },
  appBar: {
    background: '#008542',
    borderBottom: `solid 3px #FDC82F`,
    zIndex: 100
  },
  appTitle: {
    fontWeight: 500,
    fontSize: '1.3em',
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    listStyleType: 'none',
    margin: 0
  },
  appVersion: {
    fontWeight: 300,
    fontSize: '0.7em'
  },
  toolbar: {
    minHeight: 48,
    [theme.breakpoints.down('sm')]: {
      minHeight: 48
    }
  },
  menuButton: {
    color: `#ffffff`,
    marginLeft: -12,
    marginRight: 10,
    alignSelf: 'center'
  },
  invertedBtn: {
    color: '#21412a',
    backgroundColor: 'transparent',
    border: '2px #21412a solid',
    boxShadow: 'none',
    '&:hover': {
      backgroundColor: '#21412a',
      color: 'white'
    }
  },
  listStyles: {
    display: 'flex',
    margin: 0
  },
  listLi: {
    margin: '0 8px'
  },
  col1: {
    display: 'flex'
  },
  col2: {
    flex: 1
  },
  col2Top: {
    display: 'flex',
    justifyContent: 'flex-end'
  },
  menuList: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    listStyleType: 'none',
    margin: 0
  },
  ulLink: {
    textDecoration: 'none'
  }
})

export default withStyles(styles)(TopBar)
