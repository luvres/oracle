import React from 'react'
import { SwipeableDrawer, makeStyles, MenuItem } from "@material-ui/core"
import { Link } from 'react-router-dom'

const drawerWidth = 300

const useStyles = makeStyles(theme => ({
    root: {
      display: 'flex'
    },
    appBar: {
      // zIndex: theme.zIndex.drawer + 1,
      zIndex: 9999
    },
    drawer: {
      //position: "absolute",
      width: drawerWidth,
      flexShrink: 0,
      // zIndex: theme.zIndex.drawer - 1
      zIndex: 100
    },
    drawerPaper: {
      //position: "absolute",
      width: drawerWidth,
      zIndex: 100
    },
    content: {
      flexGrow: 1,
      padding: theme.spacing(1)
    },
    toolbar: theme.mixins.toolbar,
    link: {
      textDecoration: "none"
    }
  })
)

const menuItems = [
  {
    path: "./",
    label: "Análise de Offhire"
  },
  {
    path: "./about",
    label: "Análise de Underperformance"
  }
]

export default function MenuNav (props) {
    const { open, onClose, onOpen } = props
    const classes = useStyles()
    return (
      <div>
        <SwipeableDrawer
          anchor="left"
          open={open}
          onOpen={onOpen}
          onClose={onClose}
          className={classes.drawer}
          classes={{ paper: classes.drawerPaper }}
        >
          {menuItems.map((menuItem, index) => {
            return (
              <Link key={index} className={classes.link} to={menuItem.path} onClick={onClose}><MenuItem>{menuItem.label}</MenuItem></Link>
            )
          })}
        </SwipeableDrawer>
      </div>
    )
  }