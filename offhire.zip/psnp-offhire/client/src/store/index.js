import { createStore } from 'redux'
import {
  CHANGE_FLEET_FILTER,
  CHANGE_PROFILE,
  FETCH_DATA_PENDING,
  FETCH_DATA_SUCCESS,
  FETCH_DATA_ERROR,
  BUSINESS_SUCCESS,
  BUSINESS_PENDING,
  BUSINESS_ERROR,
  SHOW_SNACK,
  HIDE_SNACK,
  OPEN_MODAL,
  CLOSE_MODAL
} from '../actions/actionTypes'

const INITIAL_STATE = {
  myFleetOnly: 'S',
  profile: 'ON',
  pending: false,
  data: [],
  error: null,
  businessPending: false,
  businessError: null,
  snackShow: false,
  snackMessage: '',
  modals: []
}
function reduce (state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case OPEN_MODAL:
      return {
        ...state,
        modals: state.modals.concat(action.obj)
      }
    case CLOSE_MODAL:
      return {
        ...state,
        modals: state.modals.filter(item => item.id !== action.obj.id)
      }
    case CHANGE_FLEET_FILTER:
      return {
        ...state,
        myFleetOnly: action.myFleetOnly
      }
    case CHANGE_PROFILE:
      return {
        ...state,
        profile: action.profile
      }
    case FETCH_DATA_PENDING:
      return {
        ...state,
        pending: true
      }
    case FETCH_DATA_SUCCESS:
      return {
        ...state,
        pending: false,
        data: action.data
      }
    case FETCH_DATA_ERROR:
      return {
        ...state,
        pending: false,
        error: action.error
      }
    case BUSINESS_PENDING:
      return {
        ...state,
        businessPending: true
      }
    case BUSINESS_SUCCESS:
      return {
        ...state,
        businessPending: false,
        businessError: null
      }
    case BUSINESS_ERROR:
      return {
        ...state,
        businessPending: false,
        businessError: action.error
      }
    case SHOW_SNACK:
      return {
        ...state,
        snackShow: true,
        snackMessage: action.message
      }
    case HIDE_SNACK:
      return {
        ...state,
        snackShow: false,
        snackMessage: action.message
      }
    default:
      return state
  }
}

const store = createStore(reduce)

export default store
