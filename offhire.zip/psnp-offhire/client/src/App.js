import React from 'react'
import { Provider, useSelector } from 'react-redux'
import CssBaseline from '@material-ui/core/CssBaseline'
import Layout from './components/presentation/Layout'
import store from './store'
import { red, orange } from '@material-ui/core/colors'
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core'
import FormDialog from './components/presentation/FormDialog'

const theme = createMuiTheme({
  palette: {
    error: red,
    // Used by `getContrastText()` to maximize the contrast between the background and
    // the text.
    contrastThreshold: 3,
    // Used to shift a color's luminance by approximately
    // two indexes within its tonal palette.
    // E.g., shift from Red 500 to Red 300 or Red 700.
    tonalOffset: 0.2,
    statusRed: {
      main: '#ff0000'
    },
    background: {
      default: '#f6f6f6'
    }
  },
  status: {
    danger: orange[500]
  }
})

const ModalsContainer = () => {
  const storeModals = useSelector(state => state.modals)
  const modals = storeModals.map((item, i) => {

    return (
    <FormDialog
      item={item}
      title={item.title}
      subtitle= {item.subtitle}
      content={item.content}
      key={i}
      zindex={i}
      maxWidth={item.width || 'md'}
      fullWidth
      open={item.open != undefined ? item.open : true}
    />)
})

  return <div className={modals.length > 0 ? 'modals' : ''}>{modals}</div>
}

export default function App () {
  return (
    <Provider store={store}>
      <React.Fragment>
        <MuiThemeProvider theme={theme}>
          <CssBaseline />
          <Layout />
          <ModalsContainer />
        </MuiThemeProvider>
      </React.Fragment>
    </Provider>
  )
}
