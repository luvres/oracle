const HtmlWebPackPlugin = require('html-webpack-plugin')
const path = require('path')

module.exports = {
  entry: './src/index.js',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist')
  },
  module: {
    rules: [
      { test: /\.(js|jsx)$/, exclude: /node_modules/, loader: 'babel-loader' },
      { test: /\.html$/, use: [{ loader: 'html-loader' }] },
      {
        test: /\.scss$/,
        use: [{ loader: 'sass-loader' }]
      },
      {
        test: /\.css$/,
        use: [{ loader: 'style-loader' }, { loader: 'css-loader', options: { modules: true } }]
      },
      {
        test: /\.(woff(2)?|ttf|eot|svg)(\?v=\d+\.\d+\.\d+)?$/,
        use: [
          {
            loader: 'file-loader',
            options: { name: '[name].[ext]', outputPath: 'fonts/' }
          }
        ]
      },
      {
        // test: /\.(jpe?g|ico|gif|png|svg|xml|md)$/,
        test: /\.*$/,
        include: [
          path.resolve(__dirname, "src/favicons")
        ],
        use: [
          {
            loader: 'file-loader',  // <-- retain original file name
            options: { name: '[name].[ext]', outputPath: 'favicons/' },
          } 
        ]
      }
    ]
  },
  plugins: [
    new HtmlWebPackPlugin({
      template: './src/index.html',
      filename: './index.html'
    })
  ],
  devtool: 'source-map'
}
