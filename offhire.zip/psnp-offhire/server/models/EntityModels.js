// Mapeamento de campos e variáveis

// ATENÇÃO: Nas consultas, o Oracle retorna o nome dos campos 
// sempre em MAIÚSCULAS. Portanto, é necessário padronizar
// o nome dos atributos também em maiúsculas

module.exports = {
  timesheet: {
    map: {
      // Atributos em comum com OFFHIRE
      EMBARCACAO_ID: 'emba.emba_cd_id',
      VIAGEM_ID: 'viag.viag_cd_id',
      ESCALA_PORTO_ID: 'espt.espt_cd_id',
      PONTO_OPERACIONAL_ID: 'poop.poop_cd_id',
      DATA_INICIO: 'evt.evts_dt_inicio',
      DATA_FIM: 'evt.evts_dt_fim',
      DATA_GRAVACAO: 'evt.evts_dt_gravacao',
      CHAVE_USUARIO: 'evt.usur_cd_chave',

      // Atributos exclusivos do TIMESHEET
      OBSERVACAO: 'evt.evts_tx_observacao',
      GRUPO_EVENTO: 'gtev.gtev_nm_completo',
      EMBARCACAO_NOME: 'emba.emba_nm_completo',
      EMBARCACAO_IMO: 'emba.emba_tx_imo',
      DATA_QTP: 'espt.espt_dt_qtp_boletim',
      DATA_QTO: 'espt.espt_dt_qto_boletim',
      PORTO_NOME: 'port.port_nm_completo',
      PORTO_ID: 'port.port_cd_id',
      ORIGEM_INFORMACAO: 'orin.orin_nm_completo'
    }
  },
  offhire: {
    table: 'upsnp.TB_OFFHIRE',
    pk: 'OFFH_CD_ID',
    map: {
      // Atributos em comum com TIMESHEET
      EMBARCACAO_ID: 'EMBA_CD_ID',
      VIAGEM_ID: 'VIAG_CD_ID',
      ESCALA_PORTO_ID: 'ESPT_CD_ID',
      PONTO_OPERACIONAL_ID: 'POOP_CD_ID',
      DATA_INICIO: 'EVTS_DT_INICIO',
      DATA_FIM: 'EVTS_DT_FIM',
      DATA_GRAVACAO: 'EVTS_DT_REGISTRO',
      //CHAVE_USUARIO: 'USUR_CD_CHAVE',

      // Atributos exclusivos do OFFHIRE
      DATA_INICIO_AJUSTADA: 'OFFH_DT_INICIOAJUSTADO',
      DATA_FIM_AJUSTADA: 'OFFH_DT_FIMAJUSTADO',
      STATUS_OFFHIRE_ID: 'OFST_CD_ID',
      OFFHIRE_ID: 'OFFH_CD_ID'
    }
  },
  documento: {
    table: 'upsnp.TB_DOCUMENTO',
    pk: 'DOCU_CD_ID',
    map: {
      OFFHIRE_ID: 'OFFH_CD_ID',
      DOCUMENTO_NOME: 'DOCU_NM_DOCUMENTO',
      DOCUMENTO_DESCRICAO: 'DOCU_TX_DESCRICAO',
      ARQUIVO_BLOB: 'DOCU_BL_ARQUIVO',
      EDOC_ID: 'EDOC_CD_ID',
      DOCUMENTO_TIPO: 'DOTI_CD_ID',
      DOCUMENTO_STATUS: 'DOST_CD_ID'
    }
  },
  relato: {
    table: 'upsnp.TB_RELATO',
    pk: 'RELA_CD_ID',
    map: {
      RELATO_ID: 'RELA_CD_ID',
      RELATO_DATA_EMISSAO: 'RELA_DT_EMISSAO',
      RELATO_TEXTO: 'RELA_TX_RELATO',
      RELATO_USUARIO: 'USUR_CD_CHAVE',
      OFFHIRE_ID: 'OFFH_CD_ID',
      RELATO_STATUS: 'RLST_CD_ID'
    }
  }  
}
