import OracleDB from 'oracledb'

/** Métodos utilitários para consultas ao banco de dados */
export as namespace DatabaseUtil;


/** Pool de conexão padrão */
export const defaultPoolAlias: string;
/**
 * Inicializa as conexões ao banco de dados. 
 */
export function initialize(): Promise<void>;
/**
 * Encerra as conexões ao banco de dados.
 */
export function close(): Promise<void>;



/**
 * Executa uma consulta no banco de dados
 */
export function simpleExecute(
  /** A *query* a ser executada. */
  statement: string,
  /** Contém as variáveis utilizadas na consulta. */
  binds: any[],
  /** Nome do pool de conexão utilizado para a consulta. */
  poolAlias: string,
  /** Opções para modificar o resultado. */
  opts: object
): Promise<any>