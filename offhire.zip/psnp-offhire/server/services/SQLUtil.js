const oracledb = require('oracledb')

/** @type {SQLUtil.addPagination} */
module.exports.addPagination = function (query, context, binds) {
  const skip = context.skip && context.skip > 0 ? context.skip : 0
  const limit = context.limit && context.limit > 0 ? context.limit : 1000

  // Na chamada à API devem ser adicionados os parâmetros 'limit' e/ou 'skip'
  // Exemplos:
  //   api_url?limit=10          traz os 10 primeiros registros
  //   api_url?skip=5            traz todos os registros, com exceção dos 5 primeiros
  //   api_url?limit=10&skip=5   traz 10 registros, contando a partir do 6º

  // ATENÇÃO
  // No Oracle 11g não é possível usar FETCH ONLY e OFFSET, recursos presentes
  // somente a partir da versão 12 deste SGBD. Portanto foi usada aqui a abordagem
  // tradicional, com subconsultas

  if (limit > 0) {
    query = `SELECT a.*,
        ROWNUM rnum
      FROM (
        ${query}
      ) a
      WHERE ROWNUM <= :limit`
    binds.limit = limit

    if (skip > 0) {
      query = `SELECT *
      FROM
        (
          ${query}
        )
      WHERE rnum > :skip`
      binds.limit = limit + skip
      binds.skip = skip
    }
  }
  return query
}

/** @type {SQLUtil.addSort} */
module.exports.addSort = function (query, context, sortOptions) {
  let { sortableColumns, defaultColumn, entityModel } = sortOptions

  // Na chamada à API deve ser adicionado o parâmetro 'sort' no seguinte formato:
  // [nome_da_coluna]:['asc' | 'desc']
  // Exemplos:
  //   api_url?sort=Nome:asc     ordena a consulta pela coluna "Nome" em ordem crescente
  //   api_url?sort=Nome:desc    ordena a consulta pela coluna "Nome" em ordem decrescente

  if (context.sort === undefined) {
    query += `\nORDER BY ${defaultColumn} ASC`
  } else {
    let [column, order] = context.sort.split(':')
    column =
      column !== undefined
        ? (entityModel.map[column] || column).toUpperCase()
        : null

    sortableColumns = sortableColumns.map(col =>
      (entityModel.map[col] || col).toUpperCase()
    )

    if (!sortableColumns.includes(column)) {
      throw new Error(
        `${column} não é um critério de ordenação válido. Verifique o critério passado no fltro "&sort=[criterio]", que deve corresponder a um campo existente na consulta.`
      )
    }

    if (order === undefined) {
      order = 'asc'
    }

    if (order !== 'asc' && order !== 'desc') {
      throw new Error(
        `Direção da ordenação inválida. Deve ser "asc" ou "desc", mas foi passado "${order}".`
      )
    }

    query += `\norder by ${column} ${order}`
  }

  return query
}

/** @type {SQLUtil.simpleExecute} */
module.exports.simpleExecute = function (
  statement,
  binds = [],
  poolAlias = defaultDB,
  opts = {}
) {
  return new Promise(async (resolve, reject) => {
    let conn

    opts.outFormat = oracledb.OBJECT
    opts.autoCommit = true

    try {
      conn = await oracledb.getConnection(poolAlias)

      const result = await conn.execute(statement, binds, opts)

      resolve(result)
    } catch (err) {
      reject(err)
    } finally {
      if (conn) {
        // conn assignment worked, need to close
        try {
          await conn.close()
        } catch (err) {
          console.log(err)
        }
      }
    }
  })
}

module.exports.fieldMap = function (entity, attribute) {
  const result = []
  if (attribute != undefined) {
    if (attribute.length && attribute.length > 0) {
      attribute.forEach(attr => result.push(`${entity.map[attr]} AS ${attr}`))
    } else {
      if (typeof attribute === 'string' && attribute != '') {
        entity.map[attribute] != undefined
          ? result.push(`${entity.map[attribute]} AS ${attribute}`)
          : void 0
      }
    }
  } else {
    if (entity != undefined) {
      Object.keys(entity.map).forEach(key => {
        result.push(`${entity.map[key]} AS ${key}`)
      })
    }
  }
  return result.join(',\n')
}

module.exports.buildUpdate = function (entity, binds, bindPK) {
  let resultQuery = ''
  const fields = []
  if (entity != undefined && binds != undefined && bindPK != undefined) {
    Object.keys(binds).forEach(bind => {
      if (entity.map[bind] != undefined) {
        fields.push(`${entity.map[bind]} = :${bind}`)
      }
    })
    if (fields.length > 0) {
      resultQuery = `UPDATE ${entity.table} SET\n${fields.join(
        ',\n'
      )}\n WHERE ${entity.pk} = :${bindPK}`
    }
  }

  return resultQuery
}

module.exports.buildInsert = function (entity, binds, bindPK) {
  let resultQuery = ''
  const fields = []
  const values = []

  if (entity != undefined && binds != undefined && bindPK != undefined) {
    Object.keys(binds).forEach(bind => {
      if (entity.map[bind] != undefined) {
        fields.push(`${entity.map[bind]}`)
        values.push(`:${bind}`)
      }
    })
    if (fields.length > 0) {
      resultQuery = `INSERT INTO  ${entity.table} (${fields.join(
        ', '
      )}) VALUES (${values.join(', ')}) RETURNING ${entity.pk} INTO :${bindPK}`
    }
  }

  return resultQuery
}
