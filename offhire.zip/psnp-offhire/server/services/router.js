const express = require('express')
const router = new express.Router()
const employees = require('../controllers/employees.js')
const navios = require('../controllers/navios.js')
const offhires = require('../controllers/offhires.js')
const documents = require('../controllers/document.js')
const relatos = require('../controllers/relato.js')
const sigo = require('../controllers/sigo.js')

router.route('/employees/:id?').get(employees.get)

router.route('/navios/:id?').get(navios.get)

router
  .route('/offhires/:id?')
  .get(offhires.get)
  .post(offhires.post)
  .put(offhires.put)
  .delete(offhires.del)

router
  .route('/document/:id?')
  .get(documents.get)
  .post(documents.post)
  .put(documents.put)
  .delete(documents.del)

router
  .route('/relato/:id?')
  .get(relatos.get)
  .post(relatos.post)
  .put(relatos.put)
  .delete(relatos.del)

router.route('/sigo/timesheet/:filter?').get(sigo.getTimesheet)

// Usuários cadastrados no SIGO
// 'id' = Chave do usuário
router.route('/sigo/user/:id?').get(sigo.getUser)

// Todas as embarcações cadastradas no SIGO.
// 'id' = código da embarcação
router.route('/sigo/vessel/:id?').get(sigo.getVessel)

// Embarcações que fazem parte da "Minha Frota" de um determinado usuário
// 'user_id'  = chave do usuário
router.route('/sigo/myfleet/:user_id?').get(sigo.getMyFleet)

module.exports = router
