const oracledb = require('oracledb')
const dbConfig = require('../config/database.js')

const defaultDB = dbConfig[Object.keys(dbConfig)[0]]

module.exports.defaultPoolAlias = defaultDB.poolAlias

module.exports.initialize = async function () {
  Object.keys(dbConfig).forEach(async configKey => {
    const poolConfig = dbConfig[configKey]
    await oracledb.createPool(poolConfig)
    console.log(`Connected to ${poolConfig.poolAlias}`)
  })
}

module.exports.close = async function () {
  Object.keys(dbConfig).forEach(async configKey => {
    const poolConfig = dbConfig[configKey]
    console.log(`Disconnecting ${poolConfig.poolAlias}`)
    await oracledb.getPool(poolConfig.poolAlias).close()
  })
}

module.exports.simpleExecute = function (
  statement,
  binds = [],
  poolAlias = defaultDB,
  opts = {}
) {
  return new Promise(async (resolve, reject) => {
    let conn

    opts.outFormat = oracledb.OBJECT
    opts.autoCommit = true

    try {
      conn = await oracledb.getConnection(poolAlias)

      const result = await conn.execute(statement, binds, opts)


      resolve(result)
    } catch (err) {
      reject(err)
    } finally {
      if (conn) {
        // conn assignment worked, need to close
        try {
          await conn.close()
        } catch (err) {
          console.log(err)
        }
      }
    }
  })
}