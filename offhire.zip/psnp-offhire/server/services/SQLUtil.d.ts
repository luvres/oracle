import OracleDB from 'oracledb'

/** Métodos utilitários para consultas ao banco de dados */
export as namespace SQLUtil;

/**
 * Opções para ordenação 
 */
export interface SortOptions {
  /**
   * Colunas que podem ser utilizadas para ordenação. Se omitido, ordena pela primeira coluna em ordem crescente.
   */
  sortableColumns: string[],
  /**
   * Se a query 'sort' for omitida da URL, a coluna que será usada por padrão para ordenação.
   */
  defaultColumn?: string,
  /**
   * Entidade usada como referência para mapeamento dos campos
   */
  entityModel: object
}

/**
* Adiciona cláusula de ordenação (ORDER BY) a uma consulta
* @returns A consulta modificada após a inclusão da ordenação
*/
export function addSort(
  /** A consulta a ser modificada */
  query: string,
  /** Atributos originados na chamada à API, contendo os parâmetros e queries presentes na URL */
  context: object,
  /** Opções de ordenação */
  options: SortOptions
): string;

/** 
 * Adiciona paginação à consulta, caso os parâmetros *limit* e/ou *skip*
 * tenham sido fornecidos na URL de chamada à API.
 * Veja exemplos no corpo da função.
 * @returns A consulta modificada após a inclusão da paginação
 */
export function addPagination(
  /** A consulta a ser modificada */
  query: string,
  /** Atributos originados na chamada à API, contendo os parâmetros e queries presentes na URL */
  context: object,
  /** Variáveis utilizadas na consulta */
  binds: OracleDB.BindParameters
): string


/** Pool de conexão padrão */
export const defaultPoolAlias: string;
/**
 * Inicializa as conexões ao banco de dados. 
 */
export function initialize(): Promise<void>;
/**
 * Encerra as conexões ao banco de dados.
 */
export function close(): Promise<void>;


/** 
 * Constroi consultas simples do tipo INSERT.
 */
export function buildInsert(
  /** Entidade usada como referência para mapeamento dos campos */
  entity: object,
  /** Variáveis utilizadas na consulta */
  binds: OracleDB.BindParameters,
  /** Variável de saída da consulta (bind out). Contém o valor da chave primária após o INSERT. Útil em chaves primárias de numeração automática. */
  bindPK: string
): string

/** 
 * Constroi consultas simples do tipo UPDATE.
 */
export function buildUpdate(
  /** Entidade usada como referência para mapeamento dos campos */
  entity: object,
  /** Variáveis utilizadas na consulta */
  binds: OracleDB.BindParameters,
  /** Variável de saída da consulta (bind out). Contém o valor da chave primária após o INSERT. Útil em chaves primárias de numeração automática. */
  bindPK: string
): string

/**
 * Executa uma consulta no banco de dados
 */
export function simpleExecute(
  /** A *query* a ser executada. */
  statement: string,
  /** Contém as variáveis utilizadas na consulta. */
  binds: any[],
  /** Nome do pool de conexão utilizado para a consulta. */
  poolAlias: string,
  /** Opções para modificar o resultado. */
  opts: object
): Promise<any>

export type SortDirection = 'asc' | 'desc';

/**
 * Definição do objeto JSON retornado pela chamada à API
 */
export interface ReturnJSON {
  /**
   * Registros retornados pela consulta.
   */
  rows?: any[];
  /**
   * Quantidade de registros retornados pela consulta original, sem filtros.
   */
  originalCount: number;
  /**
   * Total de páginas, de acordo com o limite de registros por página
   * e a quantidade de registros retornados pela consulta original.
   */
  pageCount: number;
  /**
   * Quantidade máxima de registros retornados por página.
   */
  pageLimit: number;
  /**
   * Número da página atual.
   */
  pagePos: any[];
  /**
   * Nome da coluna pela qual a consulta está ordenada.
   */
  sortColumn: any[];
  /**
   * Direção da ordenação.
   */
  sortDirection: SortDirection;

}