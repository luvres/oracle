// Nas consultas, sempre que for solicitado o 'poolAlias', caso omitido
// será considerado o primeiro pool da lista abaixo.
module.exports = {
  PSNP: {
    poolAlias: "poolPSNP",
    user: "UPSNP",
    password: "UPSNP$00",
    connectString: "localhost/xe",
    poolMin: 10,
    poolMax: 10,
    poolIncrement: 0
  },
  SIGO: {
    poolAlias: "poolSIGO",  // default
    user: "SIGO_APLICACAO",
    password: "wnyr#aUp_90",
    connectString: "onyx-scan1.petrobras.com.br/exadsv01.petrobras.com.br",
    poolMin: 10,
    poolMax: 10,
    poolIncrement: 0
  }
};