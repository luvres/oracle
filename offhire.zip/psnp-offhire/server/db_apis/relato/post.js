const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const oracledb = require('oracledb')
const { relato } = require('../../models/EntityModels')

module.exports = async function (bind) {
  const binds = Object.assign({}, bind)

  binds.relato_id = {
    dir: oracledb.BIND_OUT,
    type: oracledb.DEFAULT
  }

  const query = sql.buildInsert(relato, binds, 'relato_id')
  
  const result = await db.simpleExecute(query, binds, 'poolPSNP')

  binds.relato_id = result.outBinds.relato_id[0]

  return binds
}
