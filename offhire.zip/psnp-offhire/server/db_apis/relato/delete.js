const db = require('../../services/databaseUtil')
const oracledb = require('oracledb');

const deleteSql = `begin
 
    delete from upsnp.tb_relato
    where RELA_CD_ID = :relato_id;
 
    :rowcount := sql%rowcount;
 
  end;`

  module.exports = async function (id) {
  const binds = {
    relato_id: id,
    rowcount: {
      dir: oracledb.BIND_OUT,
      type: oracledb.NUMBER
    }
  }
  const result = await db.simpleExecute(deleteSql, binds, 'poolPSNP')

  return result.outBinds.rowcount === 1
}
