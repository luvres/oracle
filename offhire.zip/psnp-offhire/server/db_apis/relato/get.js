const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const { relato } = require('../../models/EntityModels.js')


const baseQuery = `SELECT ${sql.fieldMap(relato)} FROM ${relato.table}`

module.exports = async function (context) {
  let query = baseQuery
  const binds = {}

  if (context.id) {
    binds.relato_id = context.id

    query += `\nwhere RELA_CD_ID = :relato_id`
  }

  const result = await db.simpleExecute(query, binds, 'poolPSNP')

  return result.rows
}
