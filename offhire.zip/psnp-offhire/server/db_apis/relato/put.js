const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const { relato } = require('../../models/EntityModels')

module.exports = async function (bind) {
  const binds = Object.assign({}, bind)

  const updateSQL = sql.buildUpdate(relato, binds, 'relato_id')

  const result = await db.simpleExecute(updateSQL, binds, 'poolPSNP')

  if (result.rowsAffected && result.rowsAffected === 1) {
    return binds
  } else {
    return null
  }
}
