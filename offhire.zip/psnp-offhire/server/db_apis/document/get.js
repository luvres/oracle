const db = require('../../services/databaseUtil')

const baseQuery = `SELECT
  docu.DOCU_CD_ID,
  docu.OFFH_CD_ID,
  docu.DOCU_NM_DOCUMENTO,
  docu.DOCU_TX_DESCRICAO,
  docu.DOCU_BL_ARQUIVO,
  docu.EDOC_CD_ID,
  docu.DOTI_CD_ID,
  docu.DOST_CD_ID
FROM upsnp.tb_documento docu`

module.exports = async function (context) {
  let query = baseQuery
  const binds = {}

  if (context.id) {
    binds.id = context.id

    query += `\nwhere docu.DOCU_CD_ID = :id`
  }

  const result = await db.simpleExecute(query, binds, 'poolPSNP')

  return result.rows
}
