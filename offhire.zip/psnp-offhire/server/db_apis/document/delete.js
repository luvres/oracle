const db = require('../../services/databaseUtil')
const oracledb = require('oracledb');

const deleteSql = `begin
 
    delete from tb_documento
    where DOCU_CD_ID = :id;
 
    :rowcount := sql%rowcount;
 
  end;`

  module.exports = async function (id) {
  const binds = {
    id: id,
    rowcount: {
      dir: oracledb.BIND_OUT,
      type: oracledb.NUMBER
    }
  }
  const result = await db.simpleExecute(deleteSql, binds, 'poolPSNP')

  return result.outBinds.rowcount === 1
}
