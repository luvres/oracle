const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const { document } = require('../../models/EntityModels.js')

module.exports = async function (bind) {
  const documentBinds = Object.assign({}, bind)
  
  const updateSql = sql.buildUpdate(document, documentBinds, 'id')
  
  const result = await db.simpleExecute(updateSql, documentBinds, 'poolPSNP')

  if (result.rowsAffected && result.rowsAffected === 1) {
    return documentBinds
  } else {
    return null
  }
}
