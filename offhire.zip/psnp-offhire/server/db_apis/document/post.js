const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const oracledb = require('oracledb')
const { document } = require('../../models/EntityModels.js')

module.exports = async function (bind) {
  const documentBinds = Object.assign({}, bind)

  documentBinds.doc_id = {
    dir: oracledb.BIND_OUT,
    type: oracledb.NUMBER
  }

  const query = sql.buildInsert(document, documentBinds, 'doc_id')

  const result = await db.simpleExecute(query, documentBinds, 'poolPSNP')

  documentBinds.id = result.outBinds.doc_id[0]

  return documentBinds
}
