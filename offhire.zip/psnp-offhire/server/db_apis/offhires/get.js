const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const { offhire } = require('../../models/EntityModels.js')


const baseQuery = `SELECT ${sql.fieldMap(offhire)} FROM ${offhire.table}`

module.exports = async function (context) {
  let query = baseQuery
  const binds = {}

  if (context.id) {
    binds.offhire_id = context.id

    query += `\nwhere OFFH_CD_ID = :offhire_id`
  }

  const result = await db.simpleExecute(query, binds, 'poolPSNP')

  return result.rows
}
