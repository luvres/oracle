const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const oracledb = require('oracledb')
const { offhire } = require('../../models/EntityModels')

module.exports = async function (bind) {
  const offhireBinds = Object.assign({}, bind)

  offhireBinds.offhire_id = {
    dir: oracledb.BIND_OUT,
    type: oracledb.DEFAULT
  }

  const query = sql.buildInsert(offhire, offhireBinds, 'offhire_id')
  
  const result = await db.simpleExecute(query, offhireBinds, 'poolPSNP')

  offhireBinds.offhire_id = result.outBinds.offhire_id[0]

  return offhireBinds
}
