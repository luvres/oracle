const db = require('../../services/databaseUtil')
const oracledb = require('oracledb');

const deleteSql = `begin
 
    delete from upsnp.tb_offhire
    where OFFH_CD_ID = :offhire_id;
 
    :rowcount := sql%rowcount;
 
  end;`

  module.exports = async function (id) {
  const binds = {
    offhire_id: id,
    rowcount: {
      dir: oracledb.BIND_OUT,
      type: oracledb.NUMBER
    }
  }
  const result = await db.simpleExecute(deleteSql, binds, 'poolPSNP')

  return result.outBinds.rowcount === 1
}
