const db = require('../../services/databaseUtil')
const sql = require('../../services/SQLUtil')
const { offhire } = require('../../models/EntityModels')

module.exports = async function (bind) {
  const offhireBinds = Object.assign({}, bind)

  const updateSQL = sql.buildUpdate(offhire, offhireBinds, 'offhire_id')

  const result = await db.simpleExecute(updateSQL, offhireBinds, 'poolPSNP')

  if (result.rowsAffected && result.rowsAffected === 1) {
    return offhireBinds
  } else {
    return null
  }
}
