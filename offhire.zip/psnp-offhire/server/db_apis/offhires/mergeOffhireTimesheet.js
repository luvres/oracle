/**
 * Une os dados de timesheet vindos do SIGO com os offhires registrados na
 * aplicação.
 * @param {any[]} timesheetRows Registros de timesheet obtidos do SIGO
 * @param {any[]} offhireRows Registros de offhire da aplicação
 */
const _mergeTimesheetOffhires = function (timesheetRows, offhireRows) {
  const matchKeys = [
    'EMBARCACAO_ID',
    'VIAGEM_ID',
    'ESCALA_PORTO_ID',
    'PONTO_OPERACIONAL_ID'
    // 'data_inicio',
    // 'data_fim'
  ]

  for (let index = 0; index < timesheetRows.length; index++) {
    const matchedOffhires = offhireRows.filter(
      row =>
        !matchKeys.some(
          key =>
            row[key.toUpperCase()] != timesheetRows[index][key.toUpperCase()]
        )
    )

    const matched =
      matchedOffhires.length === 1
        ? Object.assign({}, matchedOffhires[0])
        : null

    timesheetRows[index]['STATUS_OFFHIRE_ID'] = matched
      ? matched['STATUS_OFFHIRE_ID']
      : 'REGI'
    timesheetRows[index]['OFFHIRE_ID'] = matched
      ? matched['OFFHIRE_ID']
      : undefined
  }

  return timesheetRows
}

module.exports = _mergeTimesheetOffhires
