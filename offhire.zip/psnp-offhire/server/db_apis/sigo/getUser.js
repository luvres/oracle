const db = require('../../services/databaseUtil')

const oracledb = require('oracledb')

/** Valores default para os parâmetros de consulta */
const defaultValue = {
  /** Início do período considerado para consulta */
  inicio: '2017-01-01 16:30:00',
  /** Fim do período considerado para consulta */
  fim: '2018-04-30 16:30:00'
}

const base = `SELECT * FROM STM.USUARIO`

/** Colunas que poderão ser usadas para ordenação */
const sortableColumns = [
  'EMBARCACAO',
  'VIAGEM',
  'QTP',
  'PO',
  'INICIO',
  'FIM',
  'STATUS'
]

/**
 * Formata um array de strings para ser usado em cláusula IN
 * @param {string[]} arrValues Array com os valores a formatar
 * @return {string} String com os valores já separados por vírgula
 */
function formatToIN(arrValues){
  const arrResult = []

  arrValues.forEach(elem => arrResult.push(`'${elem}'`))

  return arrResult.join(',')
}

/** Usuários da ON */
const usersON = [
  'UQ40',
  'BON1',
  'WTLC',
  'FPYZ',
  'CQA4',
  'URLJ',
  'NV77',
  'DCNT',
  'T3GB',
  'CDK6',
  'FPWG',
  'U3P5',
  'FAQE',
  'Z511',
  'B227',
  'ZPBR',
  'HRH1',
  'APEV',
  'HR9G',
  'U3M7',
  'UQ9D',
  'HRC7'
]

/** Usuários da GCA */
const usersGCA = [
  'AXO2',
  'A3QZ',
  'CQA5',
  'CXN1',
  'EMJR',
  'FP9J',
  'U460',
  'WGC1'
]



/** Coluna usada por default para ordenação */
const sortByDefault = 'INICIO'

const defaultUser = 'CXN1'

module.exports = async function (context) {
  let binds = {}
  let query = null
  let filter = ''

  if (context.id && context.id.length === 4) {
    filter += `\nWHERE UPPER(usur_cd_chave) = UPPER(:user_id)`
    binds.user_id = context.id
  } else {
    filter += `\nWHERE usur_cd_chave IN (${formatToIN(usersGCA)})`
  }

  query = base + filter

  console.log(query)

  /** @type {oracledb.Result} */
  const result = await db.simpleExecute(query, binds, 'poolSIGO')

  /** @type {ReturnJSON} */
  const apiResult = {
    context,
    rows: result.rows
  }

  return apiResult
}
