const db = require('../../services/databaseUtil')
const oracledb = require('oracledb')

const base = `SELECT
    emba.emba_cd_id           id
   ,emba.emba_nm_completo     name
   ,emba.emba_nm_apelido      alias
   ,emba_tx_imo               imo
   ,tiem.tiem_nm_completo     type
   ,stat.stat_nm_completo     status
   ,clem.clem_nm_completo     class
   ,pais.pais_nm_completo     country
   ,pais.pais_tx_iso_alpha3   country_iso
FROM
    stm.embarcacao           emba
    INNER JOIN stm.tipo_embarcacao      tiem ON emba.tiem_cd_id = tiem.tiem_cd_id
    INNER JOIN stm.status_embarcacao    stat ON emba.stat_cd_id = stat.stat_cd_id
    INNER JOIN stm.classe_embarcacao    clem ON emba.clem_cd_id = clem.clem_cd_id
    INNER JOIN stm.pais                 pais ON emba.pais_cd_ibge = pais.pais_cd_ibge`

module.exports = async function (context) {
  let binds = {}
  let query = null
  let filter = ''

  if (context.id && context.id.length === 4) {
    filter += `\nWHERE UPPER(emba.emba_cd_id) = UPPER(:vessel_id)`
    binds.vessel_id = context.id
  } else {
    filter += `\nWHERE ROWNUM <= 100`
  }

  query = base + filter

  console.log(query)

  /** @type {oracledb.Result} */
  const result = await db.simpleExecute(query, binds, 'poolSIGO')

  /** @type {ReturnJSON} */
  const apiResult = {
    context,
    rows: result.rows
  }

  return apiResult
}
