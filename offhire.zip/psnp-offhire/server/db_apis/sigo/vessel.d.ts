
type VesselStatus = 'ATIVO' | 'INATIVO' | 'LAYUP' | 'SCRAPP';

type VesselType = 'NAVIO' | 'BARCAÇA' | 'REBOCADOR' | 'EMPURRADOR';

type VesselClass =
  'DRY CARGO' |
  'NAVIO DE PASSAGEIROS' |
  'MINERIO' |
  'O/O ' |
  'QUIMICO' |
  'GAS/QUIMICO' |
  'OBO' |
  'GAS/PETROLEIRO' |
  'QUIMICO/PETROLEIRO' |
  'GAS/RF' |
  'GAS SP/SR' |
  'PETROLEIRO' |
  'L.P.G. CARRIER' |
  'METHANOL CARRIER' |
  'BULK CARRIER' |
  'FULLY CELLULAR CONTAINER' |
  'ANCHOR HANDLING SUPPLY' |
  'REBOCADOR APOIO MARITIMO' |
  'MULTI-PROPÓSITO' |
  'OFFSHORE SUPPLY SHIP' |
  'OPEN HATCH CARGO SHIP' |
  'PIPE LAYER CRANE VESSEL' |
  'ACCOMMODATION PLATFORM, S' |
  'LNG CARRIER' |
  'OFFSHORE TUG/SUPPLY SHIP' |
  'OUTROS' |
  'FLOATING STORAGE/PRODUCTI' |
  'REBOCADOR APOIO PORTUÁRIO' |
  'PLATAFORM  SUPPLY VESSEL';

interface Vessel {
  /** Código identificador da embarcação */
  id: string;

  /** Nome da embarcação */
  name: string;

  /** Apelido da embarcação */
  alias: string;

  /** Código IMO (Iternational Maritime Organization) da embarcação */
  imo: string;

  /** Tipo da embarcação */
  type: VesselType;

  /** Status da embarcação */
  status: VesselStatus;

  /** Classe da embarcação */
  class: VesselClass;


  /** País de origem da embarcação */
  country: string;


  /** Código ISO do país de origem da embarcação */
  country_iso: string;

  /** Usuário que marcou esta embarcação em "Minha Frota" */
  fleetUser: string;
}