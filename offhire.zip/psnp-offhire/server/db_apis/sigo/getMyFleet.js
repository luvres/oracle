const db = require('../../services/databaseUtil')
const oracledb = require('oracledb')

const base = `SELECT
    emba.emba_cd_id           id
   ,emba.emba_nm_completo     name
   ,emba.emba_nm_apelido      alias
   ,emba_tx_imo               imo
   ,tiem.tiem_nm_completo     type
   ,stat.stat_nm_completo     status
   ,clem.clem_nm_completo     class
   ,pais.pais_nm_completo     country
   ,pais.pais_tx_iso_alpha3   country_iso
FROM
    stm.embarcacao           emba
    INNER JOIN stm.tipo_embarcacao      tiem ON emba.tiem_cd_id = tiem.tiem_cd_id
    INNER JOIN stm.status_embarcacao    stat ON emba.stat_cd_id = stat.stat_cd_id
    INNER JOIN stm.classe_embarcacao    clem ON emba.clem_cd_id = clem.clem_cd_id
    INNER JOIN stm.pais                 pais ON emba.pais_cd_ibge = pais.pais_cd_ibge
    INNER JOIN stm.usuario_embarcacao   usem ON usem.emba_cd_id = emba.emba_cd_id
  WHERE
    UPPER(usem.usur_cd_chave) = UPPER(:user_id)`

module.exports = async function (context) {
  let binds = {}
  let query = null


  binds.user_id =
    context.user_id && context.user_id.length === 4 ? context.user_id : 'BON1'

  query = base

  console.log(query, binds)

  /** @type {oracledb.Result} */
  const result = await db.simpleExecute(query, binds, 'poolSIGO')

  /** @type {ReturnJSON} */
  const apiResult = {
    context,
    rows: result.rows
  }

  return apiResult
}
