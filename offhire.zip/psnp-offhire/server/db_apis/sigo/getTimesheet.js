const sql = require('../../services/SQLUtil')
const db = require('../../services/databaseUtil')
const getOffhires = require('../offhires/get')
const { timesheet } = require('../../models/EntityModels.js')
const mergeOffhire = require('../offhires/mergeOffhireTimesheet')

const oracledb = require('oracledb')

/** Valores default para os parâmetros de consulta */
const defaultValue = {
  /** Início do período considerado para consulta */
  inicio: '2017-01-01 16:30:00',
  /** Fim do período considerado para consulta */
  fim: '2018-04-30 16:30:00'
}

const base = `SELECT
${sql.fieldMap(timesheet)},
floor(round(24 *(evt.evts_dt_fim - evt.evts_dt_inicio), 1)) AS duracao,
round(24 *(sysdate - evt.evts_dt_gravacao), 1) AS horas_aguardando,
round(24 *(evt.evts_dt_gravacao - evt.evts_dt_inicio), 1) AS tempo_registro_inicio,
round(24 *(evt.evts_dt_gravacao - evt.evts_dt_fim), 1) AS tempo_registro_fim
FROM
stm.evento_time_sheet              evt
INNER JOIN stm.escala_ponto_operacional       epo ON evt.espo_cd_id = epo.espo_cd_id
INNER JOIN stm.ponto_operacional              poop ON epo.poop_cd_id = poop.poop_cd_id
INNER JOIN stm.escala_porto                   espt ON evt.espt_cd_id = espt.espt_cd_id
INNER JOIN stm.porto                          port ON espt.port_cd_id = port.port_cd_id
INNER JOIN stm.viagem                         viag ON viag.viag_cd_id = epo.viag_cd_id1
                              AND viag.emba_cd_id = epo.emba_cd_id
INNER JOIN stm.embarcacao                     emba ON emba.emba_cd_id = epo.emba_cd_id
INNER JOIN stm.tipo_evento_time_sheet         tets ON evt.tets_cd_id = tets.tets_cd_id
INNER JOIN stm.grupo_tipo_evento_time_sheet   gtev ON tets.gtev_cd_id = gtev.gtev_cd_id
INNER JOIN stm.origem_informacao              orin ON evt.orin_cd_id = orin.orin_cd_id`

const defaultUser = 'CXN1'

module.exports = async function (context) {
  let binds = {}
  let query = null
  let filter = `\nWHERE GTEV.GTEV_CD_ID = 2 AND EVT.USUR_CD_CHAVE <> 'TELX'`

  if (context.filter) {
    switch (context.filter) {
      case 'myfleet':
        filter += `\nAND EMBA.EMBA_CD_ID IN (SELECT emba_cd_id FROM stm.usuario_embarcacao WHERE usur_cd_chave = :usu_chave)`
        binds.usu_chave = context.user ? context.user : defaultUser
        break
      default:
    }
  }
  // } else {
  //   filter += `\nAND (EVT.EVTS_DT_INICIO > :inicio_periodo AND EVT.EVTS_DT_INICIO < :fim_periodo)`
  //   binds.inicio_periodo = new Date(defaultValue.inicio)
  //   binds.fim_periodo = new Date(defaultValue.fim)
  // }

  let originalCount = -1

  query = base + filter

  // /** @type {oracledb.Result} */
  // const countQuery = await db.simpleExecute(
  //   `select count(*) as RECORDCOUNT from (${query})`,
  //   binds,
  //   'poolSIGO'
  // )

  // originalCount =
  //   countQuery.rows && countQuery.rows.length === 1
  //     ? countQuery.rows[0].RECORDCOUNT
  //     : null

  // Ordenação
  if (context.sort) {
    query = sql.addSort(query, context, {
      sortableColumns: [
        'embarcacao',
        'data_gravacao',
        'viagem',
        'qtp',
        'ponto_operacional_codigo',
        'inicio',
        'fim',
        'status',
        'duracao'
      ],
      defaultColumn: 'inicio',
      entityModel: timesheet
    })
  }

  query = sql.addPagination(query, context, binds)

  /** @type {oracledb.Result} */
  const timesheet = await db.simpleExecute(query, binds, 'poolSIGO')
 
  const offhires = await getOffhires(context)
  
  mergeOffhire(timesheet.rows, offhires)


  /** @type {SQLUtil.ReturnJSON} */
  const apiResult = {
    context,
    originalCount,
    rows: timesheet.rows,
  }

  return apiResult
}
