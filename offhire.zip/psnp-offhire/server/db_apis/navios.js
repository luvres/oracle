const db = require('../services/databaseUtil')
const defaultParams ={
  inicio: '2018-01-01 00:00:00',
  fim: '2018-04-30 00:00:00'
}
 
const baseQuery = 
  `SELECT DISTINCT
    EMBA.EMBA_CD_ID value,
    EMBA.EMBA_NM_COMPLETO label
    FROM
    STM.EVENTO_TIME_SHEET EVTS
    INNER JOIN STM.ESCALA_PORTO ESPT ON
    ESPT.ESPT_CD_ID = EVTS.ESPT_CD_ID
    INNER JOIN STM.EMBARCACAO EMBA ON
    ESPT.EMBA_CD_ID = EMBA.EMBA_CD_ID
    WHERE
    (EVTS.EVTS_DT_INICIO > TIMESTAMP '${defaultParams.inicio}'
    AND EVTS.EVTS_DT_INICIO < TIMESTAMP '${defaultParams.fim}')
    ORDER BY
    EMBA.EMBA_NM_COMPLETO`;


async function find(context) {
  let query = baseQuery;
  const binds = {};
 
  if (context.id) {
    binds.employee_id = context.id;
 
    query += `\nwhere employee_id = :employee_id`;
  }
 
  try {
    const result = await db.simpleExecute(query, binds, 'poolSIGO');
    return result.rows;
    
  } catch (error) {
    console.log(error)
  }
 
}
 
module.exports.find = find;