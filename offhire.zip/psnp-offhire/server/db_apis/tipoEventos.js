const db = require('../services/databaseUtil')

const defaultParams ={
  inicio: '2018-01-01 00:00:00',
  fim: '2018-04-30 00:00:00'
}
 
const baseQuery = 
  `SELECT * FROM TB_OFFHIRE`;


async function find(context) {
  let query = baseQuery;
  const binds = {};
 
  if (context.id) {
    binds.tipoEvento_id = context.id;
 
    query += `\nwhere OFFH_CD_ID = :offhire_id`;
  }
 
  const result = await db.simpleExecute(query, binds);
 
  return result.rows;
}
 
module.exports.find = find;