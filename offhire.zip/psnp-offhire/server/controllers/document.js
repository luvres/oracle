const dbGET = require('../db_apis/document/get');
const dbPOST = require('../db_apis/document/post');
const dbPUT = require('../db_apis/document/put');
const dbDELETE = require('../db_apis/document/delete');
 
//GET
module.exports.get = async function (req, res, next) {
  try {
    const context = {};
 
    context.id = parseInt(req.params.id, 10);
 
    const rows = await dbGET(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

// POST
function getDocumentFromRec(req) {
  const document = {}

  Object.keys(req.body).forEach(prop => document[prop] = req.body[prop])
  
  // const document = {
  //   offhire_id: req.body.offhire_id,
  //   doc_name: req.body.doc_name,
  //   doc_description: req.body.doc_description,
  //   blob_file: req.body.blob_file,
  //   edoc_id: req.body.edoc_id,
  //   doc_type: req.body.doc_type,
  //   doc_status: req.body.doc_status
  // };

  return document;
}

module.exports.post =  async function (req, res, next) {
  try {
    let document = getDocumentFromRec(req);
 
    document = await dbPOST(document);
 
    res.status(201).json(document);
  } catch (err) {
    next(err);
  }
}

// PUT
module.exports.put = async function (req, res, next) {
  try {
    let document = getDocumentFromRec(req);
 
    document.id = parseInt(req.params.id, 10);
 
    document = await dbPUT(document);
 
    if (document !== null) {
      res.status(200).json(document);
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}

// DELETE
module.exports.del = async function (req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
 
    const success = await dbDELETE(id);
 
    if (success) {
      res.status(204).end();
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}
