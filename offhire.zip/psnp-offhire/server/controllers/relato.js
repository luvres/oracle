const dbGET = require('../db_apis/relato/get');
const dbPOST = require('../db_apis/relato/post');
const dbPUT = require('../db_apis/relato/put');
const dbDELETE = require('../db_apis/relato/delete');
 
//GET
module.exports.get = async function (req, res, next) {
  try {
    const context = {};
 
    context.id = parseInt(req.params.id, 10);
 
    const rows = await dbGET(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}


module.exports.post =  async function (req, res, next) {
  try {

    const newRecord = await dbPOST(req.body);
 
    res.status(201).json(newRecord);
  } catch (err) {
    next(err);
  }
}

// PUT
module.exports.put = async function (req, res, next) {
  try {
    let updatedRecord = req.body
    updatedRecord.relato_id = parseInt(req.params.id, 10);
 
    updatedRecord = await dbPUT(updatedRecord);
 
    if (updatedRecord !== null) {
      res.status(200).json(updatedRecord);
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}

// DELETE
module.exports.del = async function (req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
 
    const success = await dbDELETE(id);
 
    if (success) {
      res.status(204).end();
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}
