const dbGET = require('../db_apis/offhires/get');
const dbPOST = require('../db_apis/offhires/post');
const dbPUT = require('../db_apis/offhires/put');
const dbDELETE = require('../db_apis/offhires/delete');
 
//GET
module.exports.get = async function (req, res, next) {
  try {
    const context = {};
 
    context.id = parseInt(req.params.id, 10);
 
    const rows = await dbGET(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

// POST
function getOffhireFromRec(req) {

  const offhire = {
    voyage_id: req.body.voyage_id,
    port_id: req.body.port_id,
    port_call_id: req.body.port_call_id,
    original_start: req.body.original_start,
    original_end: req.body.original_end,
    adjusted_start: req.body.adjusted_start,
    adjusted_end: req.body.adjusted_end,
    ship_id: req.body.ship_id,
    user_id: req.body.user_id,
    status_id: req.body.status_id
  };

  return offhire;
}

const reqbody = {
  "voyage_id": "V001",
  "port_id": "P001",
  "port_call_id": "PC01",
  "original_start": "2019-11-16T17:00:00.000Z",
  "original_end": "2019-11-17T17:00:00.000Z",
  "adjusted_start": "",
  "adjusted_end": "",
  "ship_id": "6305",
  "user_id": "FRAS",
  "status_id": "REGI"
}

module.exports.post =  async function (req, res, next) {
  try {

    offhire = await dbPOST(req.body);
 
    res.status(201).json(offhire);
  } catch (err) {
    next(err);
  }
}

// PUT
module.exports.put = async function (req, res, next) {
  try {
    // let offhire = getOffhireFromRec(req);
    let offhire = req.body
    offhire.offhire_id = parseInt(req.params.id, 10);
 
    offhire = await dbPUT(offhire);
 
    if (offhire !== null) {
      res.status(200).json(offhire);
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}

// DELETE
module.exports.del = async function (req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
 
    const success = await dbDELETE(id);
 
    if (success) {
      res.status(204).end();
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}
