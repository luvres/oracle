const dbTimesheet = require('../db_apis/sigo/getTimesheet')
const dbUser = require('../db_apis/sigo/getUser')
const dbVessel = require('../db_apis/sigo/getVessel')
const dbMyFleet = require('../db_apis/sigo/getMyFleet')
 
//GET
module.exports.getTimesheet = async function (req, res, next) {
  try {
    const context = {};

    context.filter = req.params.filter;
    context.skip = parseInt(req.query.skip, 10);
    context.limit = parseInt(req.query.limit, 10);
    context.sort = req.query.sort;
    context.user = req.query.user ? req.query.user.toUpperCase() : null;
 
    const result = await dbTimesheet(context);
 
    if (result.rows.length > 0){ 
      res.status(200).json(result)
    } else {
      res.status(404).end();
    }


  } catch (err) {
    next(err);
  }
}

module.exports.getUser = async function (req, res, next) {
  try {
    const context = {};

    context.id = req.params.id;

    const result = await dbUser(context);
 
    if (result.rows.length > 0){ 
      res.status(200).json(result)
    } else {
      res.status(404).end();
    }


  } catch (err) {
    next(err);
  }
}


module.exports.getVessel = async function (req, res, next) {
  try {
    const context = {};

    context.id = req.params.id;

    const result = await dbVessel(context);
 
    if (result.rows.length > 0){ 
      res.status(200).json(result)
    } else {
      res.status(404).end();
    }


  } catch (err) {
    next(err);
  }
}

/** Embarcações pertencentes à "Minha Frota" de um determinado usuário */
module.exports.getMyFleet = async function (req, res, next) {
  try {
    const context = {};

    context.user_id = req.params.user_id || 'UQ40';

    const result = await dbMyFleet(context);
 
    if (result.rows.length > 0){ 
      res.status(200).json(result)
    } else {
      res.status(404).end();
    }


  } catch (err) {
    next(err);
  }
}